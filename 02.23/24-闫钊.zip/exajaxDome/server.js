const express = require("express");
const app = express();

const cors = require("cors");
app.use(cors());

// const bodyParser = require("body-parser");
// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());



app.use('/api/student', require("./routes/student"));

// app.use("/index", require("./routes/index.js"));
// app.get("/", (req, res) => {
//     res.redirect("/index");
// });

// app.get('/', (req, res) => {
//     res.status(200).send('chenggong');
// });

app.listen(3008, () => {
    console.log("3008端口已经开启");
});