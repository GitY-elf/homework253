const mongoose = require("mongoose");
const studentScema = new mongoose.Schema({
    gender: {
        type: String,
        enum: {
            values: ["男", "女", "保密"],
            message: "性别信息,如果不知道,请到专业机构确定"
        }
    },
    hobby: String,
    address: String,
    clazz: String,
    name: String,
    age: {
        type: Number,
        min: [18, '年龄不能小于18'],
        max: [100, '年龄不能大于100']
    },
    tel: {
        type: String,
        minlength: [11, "最小11位"],
        maxlength: [11, "最大11位"]
    },
    remark: String,
    date: {
        type: Date,
        default: Date.now
    },
    id: String
});

const students = mongoose.model("studentinfo", studentScema);

module.exports = students;

// module.exports.students = students;