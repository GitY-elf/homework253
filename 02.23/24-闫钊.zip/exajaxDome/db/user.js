const mongoose = require("mongoose");

const userScema = new mongoose.Schema({
    uname: {
        type: String,
        minlength: [2, "小于最小长度2"],
        maxlength: [4, "大于最长长度4"],
        required: [true, "必填项数据,不能为null"],
        trim: true
    },
    age: {
        type: Number,
        min: [18, '年龄不能小于18'],
        max: [100, '年龄不能大于100']
    },
    gender: {
        type: String,
        enum: {
            values: ["男", "女", "保密"],
            message: "性别信息,如果不知道,请到专业机构确定"
        }
    },
    createtime: {
        type: Date,
        default: Date.now
    }
});

const user = mongoose.model("user", userScema);

module.exports = user;