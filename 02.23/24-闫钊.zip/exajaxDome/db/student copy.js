const mongoose = require("mongoose");

const db = mongoose.connect("mongodb://localhost/studentdb", { useNewUrlParser: true, useUnifiedTopology: true });

db.then(() => {
    console.log("数据库连接成功");
}, () => {
    console.log("数据库连接失败");
});

const studentScema = new mongoose.Schema({
    gender: {
        type: String,
        enum: {
            values: ["男", "女", "保密"],
            message: "性别信息,如果不知道,请到专业机构确定"
        }
    },
    hobby: String,
    address: String,
    clazz: String,
    name: String,
    age: {
        type: Number,
        min: [18, '年龄不能小于18'],
        max: [100, '年龄不能大于100']
    },
    tel: {
        type: String,
        minlength: [11, "最小11位"],
        maxlength: [11, "最大11位"]
    },
    remark: String,
    data: {
        type: Date,
        default: Date.now
    }
});

const students = mongoose.model("studentinfo", studentScema);

students.find().then((data) => {
    console.log(data);
});