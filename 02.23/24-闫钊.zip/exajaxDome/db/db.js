const mongoose = require("mongoose");

const db = mongoose.connect("mongodb://localhost/studentdb", { useNewUrlParser: true, useUnifiedTopology: true });

db.then(() => {
    console.log("数据库连接成功");
}, () => {
    console.log("数据库连接失败");
});