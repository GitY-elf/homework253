const express = require("express");
let router = express.Router();


const bodyParser = require("body-parser");
router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());

require("../db/db");
const stuScema = require("../db/student.js")

// 查询数据 getStudent
router.get("/getStudent", (req, res) => {
    let thisname = req.query.sname;
    if (thisname) {
        stuScema.find({ name: RegExp(thisname) }).then((data) => {
            res.status(200).send(data);
        });
    } else {
        stuScema.find().then((data) => {
            res.status(200).send(data);
        });
    }
    // res.send("ok")
});

// // 删除数据 removeStudent
router.get("/removeStudent", (req, res) => {
    let stuMas = req.query;
    if (stuMas.id) {
        stuScema.deleteOne(stuMas).then((data) => {

            res.status(200).send(data);
        });
    } else {
        res.status(500).send("error");
    };
});

// // 添加数据 addStudent
router.post("/addStudent", (req, res) => {
    let stuMas = req.body;

    stuScema.create(stuMas).then((rel) => {
        res.status(200).send("ok");
    });
});


//更新数据
router.post("/updateStudent", (req, res) => {
    let stuMas = req.body;
    if (stuMas.id) {
        stuScema.updateOne({ id: stuMas.id }, stuMas).then(() => {
            res.status(200).send("ok");
        });
    } else {
        res.status(500).send("error");
    }
});


module.exports = router;