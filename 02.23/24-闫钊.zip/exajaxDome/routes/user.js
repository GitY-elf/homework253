const express = require("express");

let router = express.Router();

require("../db/db.js")
const user = require("../db/user.js");

router.get("/user", (req, res) => {
    user.find().then((data) => {
        res.status(200).send(data)
    });
});

module.exports = router;