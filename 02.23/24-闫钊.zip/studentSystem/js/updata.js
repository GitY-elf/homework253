// 服务器的路径
var requestUrl = "http://localhost:3008";

//获得学生的ID
var stuId = location.search.split("=")[1];

//获取form表单
var updataForm = document.querySelector("#updata_form");

//获取全部可以得到value的元素
var stuInfor = document.querySelectorAll(".stu_infor");

//获取性别
var gender = document.querySelectorAll("input[name=gender]");

//获取爱好
var hobbies = document.querySelectorAll("input[name=hobby]");

//设置信息
var setInfor = requestUrl + "/api/student/getStudent";

ajaxGetRequest(setInfor, { id: stuId }, function(xhr) {

    var studentObj = JSON.parse(xhr.responseText)[0];
    //设置value值的信息
    for (var i = 0; i < stuInfor.length; i++) {
        stuInfor[i].value = studentObj[stuInfor[i].name];
    };

    // 设置性别
    for (var j = 0; j < gender.length; j++) {
        if (studentObj.gender == gender[j].value) {
            gender[j].checked = true;
            break;
        };
    };

    //设置爱好
    for (var k = 0; k < hobbies.length; k++) {
        if (studentObj.hobby.includes(hobbies[k].value)) {
            hobbies[k].checked = true;
        };
    };

});


//学生信息对象
var allStuInfor = {}

//绑定表单提交事件
updataForm.onsubmit = function(e) {

    allStuInfor.id = stuId;

    //将value保存到学生信息对象中
    for (var i = 0; i < stuInfor.length; i++) {
        allStuInfor[stuInfor[i].name] = stuInfor[i].value;
    };

    //添加性别
    for (var j = 0; j < gender.length; j++) {
        //判断性别
        if (gender[j].checked) {
            allStuInfor.gender = gender[j].value;
            break;
        };
    };

    //添加爱好信息
    var hobbyArray = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            hobbyArray.push(hobbies[k].value);
        };
    };

    allStuInfor.hobby = hobbyArray.join();

    console.log(allStuInfor);
    var addUrl = requestUrl + "/api/student/updateStudent";
    ajaxPostRequest(addUrl, allStuInfor, function() {
        location.href = location.origin + "/index.html";
    });

    //阻止默认事件,防止页面刷新
    e.preventDefault();
}