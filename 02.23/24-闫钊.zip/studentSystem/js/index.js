var table = document.querySelector("table");
var tbody = document.querySelector("tbody");

//获取要搜索的姓名
var sname = document.querySelector("#sname");
var searchBtn = document.querySelector(".search");

//点击搜索
searchBtn.onclick = function() {
    getStudeng(sname.value);
};

//搜索函数  [name]:点击搜索查找name相关的信息,不传参,查找全部
function getStudeng(name) {
    console.log("name:" + name);
    var url = "http://localhost:3008/api/student/getStudent";
    if (name) {
        url = url + "?name=" + name;
    };
    console.log(url);

    var xhr = new XMLHttpRequest();
    xhr.open("GEt", url);
    xhr.send();

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304) {
                console.log("ok");
                var objArray = JSON.parse(xhr.response);
                addEle(objArray);
                remove();
            } else {
                alert("请求失败");
            };
        };
    };
};

function addEle(objArray) {
    /*
     * 给tbody添加信息
     */
    // 添加tr
    var innerStr = "";
    for (var i = 0; i < objArray.length; i++) {

        innerStr = `<tr>
        <td>${objArray[i].sid}</td>
        <td>${objArray[i].clazz}</td>
        <td>${objArray[i].name}</td>
        <td>${objArray[i].gender}</td>
        <td>${objArray[i].age}</td>
        <td>${objArray[i].tel}</td>
        <td>${objArray[i].hobby}</td>
        <td>${objArray[i].address}</td>
        <td>${objArray[i].remark}</td>
        <td>${objArray[i].date}</td>
        <td>
            <a href="javascript:void(0)"  calss='updata' data-indexID="${objArray[i].id}">修改</a>
            <a href="javascript:void(0)" class='del' data-indexID="${objArray[i].id}">删除</a>
        </td>
    </tr>`;
    };
    if (innerStr) {
        tbody.innerHTML = innerStr;
    } else {
        tbody.innerHTML = " ";
    }
};

//删除信息
function remove() {
    var delList = document.querySelectorAll(".del");
    for (var i = 0; i < delList.length; i++) {
        delList[i].onclick = function(e) {
            var str = "?id=" + e.target.parentNode.parentNode.firstElementChild.innerText;
            var xhr = new XMLHttpRequest();
            xhr.open("GET", ("http://localhost:3008/api/student/removeStudent" + str));
            xhr.send();
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4) {
                    if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304) {
                        console.log("ok");
                        getStudeng();
                    } else {
                        alert("请求失败");
                    };
                };
            };
        };
    };
};

//进入初始化页面
getStudeng();