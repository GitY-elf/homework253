// GET 发送请求
function ajaxGetRequest(url, data, fun) {
    var xhr = new XMLHttpRequest();
    console.log(dataFormatObj(data));
    xhr.open("GEt", url + "?" + dataFormatObj(data));
    xhr.send();

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304) {
                console.log(xhr.responseText);
                fun(xhr);
            } else {
                alert("请求失败");
            };
        };
    };

};

// POST 发送请求
function ajaxPostRequest(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", url);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(data));
    console.log("1111");
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            if ((xhr.status >= 200 && xhr.status < 300) || xhr.status == 304) {
                if (fun) {
                    fun(xhr);
                };
            } else {
                alert("请求失败");
            };
        };
    };

};

//格式化数据
function dataFormatObj(dataObj) {

    if (!dataObj) {
        return "";
    };

    var arrtemp = [];
    for (var key in dataObj) {
        arrtemp.push(key + "=" + dataObj[key]);
    }
    return arrtemp.join("&");
}