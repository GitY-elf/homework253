var table = document.querySelector("table");
var tbody = document.querySelector("tbody");

//获取要搜索的姓名
var sname = document.querySelector("#sname");
var searchBtn = document.querySelector(".search");

// 服务器的路径
var requestUrl = "http://localhost:3008";

//点击搜索
searchBtn.onclick = function() {
    getStudeng(sname.value);
};

function getStudeng(value) {
    var getUrl = requestUrl + "/api/student/getStudent";
    if (value) {
        ajaxGetRequest(getUrl, { sname: value }, addEle);
    } else {
        ajaxGetRequest(getUrl, {}, addEle);
    };

};

function addEle(xhr) {

    var objArray = JSON.parse(xhr.responseText);
    /*
     * 给tbody添加信息
     */
    // 添加tr
    var innerStr = "";
    for (var i = 0; i < objArray.length; i++) {

        innerStr += `<tr>
        <td>${objArray[i].id}</td>
        <td>${objArray[i].clazz}</td>
        <td>${objArray[i].name}</td>
        <td>${objArray[i].gender}</td>
        <td>${objArray[i].age}</td>
        <td>${objArray[i].tel}</td>
        <td>${objArray[i].hobby}</td>
        <td>${objArray[i].address}</td>
        <td>${objArray[i].remark}</td>
        <td>${objArray[i].date}</td>
        <td>
            <a href="./page/updata.html?id=${objArray[i].id}"  class='upd' data-indexid="${objArray[i].id}">修改</a>
            <a href="javascript:void(0)" class='del' data-indexid="${objArray[i].id}">删除</a>
        </td>
    </tr>`;
    };
    if (innerStr) {
        tbody.innerHTML = innerStr;
        //添加删除和修改事件
        addEvent();
    } else {
        tbody.innerHTML = " ";
    };
};

getStudeng();

function addEvent() {
    removeClick();
    updataClick();
}

//删除信息事件
function removeClick() {
    var delList = document.querySelectorAll(".del");
    for (var i = 0; i < delList.length; i++) {
        delList[i].onclick = function(e) {
            console.log(e.target);
            var removeUrl = requestUrl + "/api/student/removeStudent";
            this.parentNode.parentNode.remove();
            var delId = this.dataset.indexid;
            console.log(delId);

            ajaxGetRequest(removeUrl, { id: delId }, addEle);
        };
    };
};

//修改信息事件
function updataClick() {
    var updataList = document.querySelectorAll(".upd");
    console.log(updataList);
    for (var i = 0; i < updataList.length; i++) {
        updataList[i].onclick = function(e) {
            var sid = this.dataset.indexid;
            localStorage.setItem("sId", sid);
            // location.href = location.origin + "/page/updata.html";
        };
    };
};