var express = require('express');
var router = express.Router();

// 引入连接数据库的代码
require('../db/db.js');
let User = require('../db/userschma');

// 查询学生
router.get('/getStudent', function(req, res) {
    console.log(req.query);
    if (req.query) {
        User.find(req.query).then((data) => {
            res.status(200).send(data);
        });
    } else {
        User.find().then((data) => {
            res.status(200).send(data);
        });
    }
    // var results = [];

    // // 指定的id
    // var myid = req.query._id;

    // // 指定的name
    // var myname = req.query.name;

    // console.log(myid)
    // console.log(myname)

    // // 获取指定id的学生信息
    // if (myid) {
    //     User.find(req.query).then((data) => {
    //         res.status(200).send(data);
    //         results.push(data);
    //     });

    // } else if (myname) {
    //     // 获取指定name的学生信息
    //     User.find(req.query).then((data) => {
    //         res.status(200).send(data);
    //         results.push(data);
    //     });

    // } else {
    //     // 获取所有学生
    //     User.find().then((data) => {
    //         results.push(data);
    //     });
    // }

    // res.status(200).send(results);
});
router.post('/addStudent', function(req, res) {
    console.log(req.body);
    User.create(req.body).then((rel) => {
        console.log(rel);
        res.status(200).send();
    });
});
router.get('/removeStudent', function(req, res) {
    User.deleteOne({ _id: req.query._id }).then((rel) => {
        console.log(rel);
    });
})
router.post('/updateStudent', function(req, res) {
    console.log(111);
    console.log(req.body);
    console.log(req.body.id);
    User.updateOne({ _id: req.body.id }, req.body).then((rel) => {
        console.log(rel);
    });
})


// module.exports 提供了暴露接口的方法
module.exports = router;