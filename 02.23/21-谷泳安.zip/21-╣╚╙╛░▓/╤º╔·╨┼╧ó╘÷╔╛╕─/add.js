var baseURL = 'http://localhost:3008';
var allStudInfo = {};
$('#Form').submit(function(e) {
    $('.stu-data').each(function() {
        allStudInfo[this.name] = this.value;
    })
    $('.sex').each(function() {
        if (this.checked) {
            allStudInfo.sex = this.value;
        };
    })
    var tempHobby = [];
    $('.hobby').each(function() {
        if (this.checked) {
            tempHobby.push(this.value);
        }
    })
    allStudInfo.hobby = tempHobby.join();
    console.log(allStudInfo);
    $.post(baseURL + '/api/student/addStudent', allStudInfo, function() {
        location.href = '表格.html';
    });
    // 阻止默认行为,提交表单,并刷新页面
    e.preventDefault();
})