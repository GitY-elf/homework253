var baseURL = 'http://localhost:3008';
$.get(baseURL + '/api/student/getStudent', '', showpage, 'json');

function showpage(jsondate) {
    var tbodyinner = '';
    $(jsondate).each(function() {
        tbodyinner += `<tr>
        <td>${this._id}</td>
        <td>${this.clazz}</td>
        <td>${this.name}</td>
        <td>${this.sex}</td>
        <td>${this.age}</td>
        <td>${this.tel}</td>
        <td>${this.hobby}</td>
        <td>${this.address}</td>
        <td>${this.remark}</td>
        <td>${this.date}</td>
        <td><a href="update.html?id=${this._id}" class="update_btn" data-stud-id="${this.id}">修改</a><a href="javascript:void(0)" class="delete_btn" id="${this._id}">删除</a></td></tr>`

    })
    $('tbody').html(tbodyinner)
    addEvent();
}

function addEvent() {
    $('.delete_btn').click(function() {
        var that = this;
        var flag = confirm('您确定要删除吗?');
        if (flag) {
            console.log('删除了');
            $.get(baseURL + '/api/student/removeStudent', { _id: this.id }, function() {

            })
            $(that).parents('tr').remove();

        };
    })
    $('.update_btn').click(function() {
        localStorage.setItem('stuId', this.dataset.studId);
    })
};
// 搜索
$('#btn1').click(function() {
    var stuValue = $('#uname').val().trim();
    $.get(baseURL + '/api/student/getStudent', { name: stuValue }, showpage, 'json');
})
$('#btn2').click(function() {
    location.href = 'add.html'
})