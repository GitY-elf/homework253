var baseURL = 'http://localhost:3008';
var studUpdateId = location.search.split('=')[1];
$.get(baseURL + '/api/student/getStudent', { _id: studUpdateId }, function(data) {
        // 获取
        var studUpdateObj = $(data).get(0);
        console.log(studUpdateObj);
        // var studUpdateObj = data;
        $('.stu-data').each(function() {
            $(this).val(studUpdateObj[this.name])
        })
        $('.sex').each(function() {
            if (this.value == studUpdateObj.sex) {
                this.checked = true;
            };
        })
        $('.hobby').each(function() {
            if (studUpdateObj.hobby.includes(this.value)) {
                this.checked = true;
            };
        })
    })
    // 学生的总数据
var allStudInfo = {};
$('#Form').submit(function(e) {
    $('.stu-data').each(function() {
        allStudInfo[this.name] = this.value;
    })
    $('.sex').each(function() {
        if (this.checked) {
            allStudInfo.sex = this.value;
        };
    })
    var tempHobby = [];
    $('.hobby').each(function() {
        if (this.checked) {
            tempHobby.push(this.value);
        }
    })
    allStudInfo.hobby = tempHobby.join();
    // 设置学生数据对象的id值
    allStudInfo.id = studUpdateId;
    // 发送post请求，添加数据
    console.log(allStudInfo);

    $.post(baseURL + '/api/student/updateStudent', allStudInfo, function() {
        console.log(111);
    })
    location.href = '表格.html';
    // 阻止默认行为,提交表单,并刷新页面
    e.preventDefault();
})