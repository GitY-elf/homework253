// 引入模块
const express = require('express');
const app = express();
const bodyParser = require('body-parser');

// 静态托管
app.use(express.static(__dirname));

// POST请求时使用
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

// 解决跨域
const cors = require('cors');
app.use(cors());

// 分发路由
let router = require('./routes/students.js');

app.use('/', router);

// 监听端口
app.listen(3008, () => {
    console.log('服务器正在运行');
});

