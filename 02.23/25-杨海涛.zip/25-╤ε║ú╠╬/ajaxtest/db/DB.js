// 引入mongoose模块
const mongoose = require('mongoose');
// 连接数据库
let DB = mongoose.connect('mongodb://localhost/studentdb',{ useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('数据库连接成功');
},() => {
    console.log('数据库连接失败');
});