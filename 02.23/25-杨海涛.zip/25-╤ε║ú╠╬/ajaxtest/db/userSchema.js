// 定义集合规则
const mongoose = require('mongoose')
let userSchema = new mongoose.Schema({
    name: String,
    age: Number,
    gender: String,
    clazz: String,
    tel: Number,
    remark: String,
    date: Date,
    hobby: String,
    address: String,
});
const User = mongoose.model('user',userSchema);

// 暴露出 User
module.exports = User;