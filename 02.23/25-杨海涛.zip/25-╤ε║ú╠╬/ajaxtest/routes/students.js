const express = require('express');
const router = express.Router();

// 引入数据库的连接
require('../db/DB.js');
let user = require('../db/userSchema.js');

// 查找数据
router.get('/api/student/getStudent', (req, res) => {
    if (req.query.name) {
        user.find({ "name": req.query.name }).then((data) => {
            res.status(200).send(data);
        });
    } else if (req.query._id){
        user.find({ "_id": req.query._id }).then((data) => {
            res.status(200).send(data);
        });
    } else {
        user.find().then((data) => {
            res.status(200).send(data);
        });
    };
});

// 增加数据
router.post('/api/student/addStudent', (req, res) => {
    user.create(req.body).then((rel) => {
        res.status(200).send('添加成功')
    });
    res.end();
});

// 修改数据
router.post('/api/student/updateStudent', (req, res) => {
    user.updateOne({_id: req.body.id},req.body).then((rel)=>{
        console.log(rel);
        // res.status(200).send('修改成功')
    })
    res.end();
})

// 删除数据
router.get('/api/student/removeStudent', (req, res) => {
    console.log(req.query._id);
    user.deleteOne({_id: req.query._id}).then((rel) => {
        console.log(rel);
    })
})
// 暴露router
module.exports = router;