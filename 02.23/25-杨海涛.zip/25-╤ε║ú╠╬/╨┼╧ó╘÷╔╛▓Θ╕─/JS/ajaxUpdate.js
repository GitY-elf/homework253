var baseUrl = 'http://localhost:3008/';
// 获取form
var updataForm = document.querySelector('form');

// 获取id
var updateId = location.search.split('=')[1];

//获取类名
var studts = document.querySelectorAll('.studt');
var genders = document.querySelectorAll('.gender');
var hobbys = document.querySelectorAll('.hobby');
var date = document.querySelector('.date');
GetData(baseUrl + 'api/student/getStudent', { _id: updateId },function(xhr) {
    var stuObj = JSON.parse(xhr.responseText)[0];
    console.log(stuObj);  //对象
    for(var i=0;i<studts.length;i++) {
        studts[i].value = stuObj[studts[i].name];
    }

    date.value = stuObj.date.split('T')[0]
    //性别
    for(var j=0;j<genders.length;j++) {
        if(genders[j].value == stuObj.gender) {
            genders[j].checked = true;
        }
    }

    // 爱好
    for(var k=0;k<hobbys.length;k++) {
        console.log(stuObj.hobby)
        if(stuObj.hobby.includes(hobbys[k].value)) {
            hobbys[k].checked = true;
        }
    }
})

var sub2 = document.querySelector('.sub2');

sub2.onclick = function () {
    var stuId = updateId;
    var formdata = new FormData(updataForm);
    var Clazz = formdata.get('clazz');
    var names = formdata.get('name');
    var checked = formdata.get('checked');
    var age = formdata.get('age');
    var tel = formdata.get('tel');
    var hobbys = formdata.getAll('hobby');
    var address = formdata.get('address');
    var remark = formdata.get('remark');
    var date = formdata.get('date');

    // 多个爱好转换为字符
    var hobby = hobbys.join(',');
    
    var objStudent = {
        id: stuId,
        clazz: Clazz,
        name: names,
        gender: checked,
        age: age,
        tel: tel,
        hobby: hobby,
        address: address,
        remark: remark,
        date: date
    }
    // console.log(objStudent);
    // console.log(JSON.stringify(objStudent));
    
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "http://localhost:3008/api/student/updateStudent");
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(objStudent));
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            console.log(xhr.responseText);
            location.href = location.href = location.origin + '/ajax信息获取删除.html';
        }
    }
   
}
