var formData = document.querySelector('form');
var sub1 = document.querySelector('.sub1');

sub1.onclick = function () {
    var formdata = new FormData(formData);
    var Clazz = formdata.get('clazz');
    var names = formdata.get('uname');
    var checked = formdata.get('checked');
    var age = formdata.get('age');
    var tel = formdata.get('tel');
    var hobbys = formdata.getAll('hobby');
    var address = formdata.get('address');
    var remark = formdata.get('remark');
    var date = formdata.get('date');

    var id = formdata.get('id');

    
    // 多个爱好转换为字符
    var hobby = hobbys.join(',')
    
    var objStudent = {
        clazz: Clazz,
        name: names,
        gender: checked,
        age: age,
        tel: tel,
        hobby: hobby,
        address: address,
        remark: remark,
        date: date,
        id: id
    }
    // console.log(objStudent);
    // console.log(JSON.stringify(objStudent));
    
    console.log(location.origin + '/ajax信息获取删除.html')
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "http://localhost:3008/api/student/addStudent");
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(objStudent));
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            console.log(xhr.responseText);
            // location.href = location.origin + 'E:/VScode/25-杨海涛/02-信息增删插改/ajax信息获取删除.html';
            location.href = location.origin + '/ajax信息获取删除.html';
        }
    }
}
