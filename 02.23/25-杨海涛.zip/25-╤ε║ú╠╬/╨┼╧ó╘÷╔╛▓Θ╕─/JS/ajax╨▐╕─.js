var tBody = document.querySelector('.Tbody')
var xhr = new XMLHttpRequest();
xhr.open('GET', 'http://localhost:3008/api/student/getStudent');
xhr.send(null);
xhr.onreadystatechange = function () {
    if (xhr.readyState == 4 && xhr.status == 200) {
        var arrStudent = JSON.parse(xhr.responseText);
        console.log(arrStudent)
        var list = '';
        for (var i = 0; i < arrStudent.length; i++) {
            list += '<tr><td>' + arrStudent[i].id + '</td>' +
                '<td>' + arrStudent[i].clazz + '</td>' +
                '<td>' + arrStudent[i].name + '</td>' +
                '<td>' + arrStudent[i].gender + '</td>' +
                '<td>' + arrStudent[i].age + '</td>' +
                '<td>' + arrStudent[i].tel + '</td>' +
                '<td>' + arrStudent[i].hobby + '</td>' +
                '<td>' + arrStudent[i].address + '</td>' +
                '<td>' + arrStudent[i].remark + '</td>' +
                '<td>' + arrStudent[i].date + '</td>' +
                '<td><a href="../ajax信息获取删除.html" class="btn1">修改</a>' + "" +
                '<a href="#" class="btn2">删除</a></td></tr>'
        }
    }
    tBody.innerHTML = list;
    var btn2 = document.querySelectorAll('.btn2');
    del(btn2);
}


var Text = document.querySelector('.Text');
var btn = document.querySelector('.btn');
btn.onclick = function () {
    var xhr = new XMLHttpRequest();
    var nameValue = Text.value;
    console.log(nameValue);
    xhr.open('GET', 'http://localhost:3008/api/student/getStudent?name=' + nameValue);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var arrStudent = JSON.parse(xhr.responseText);
            // console.log(arrStudent)
            var list = '';
            for (var i = 0; i < arrStudent.length; i++) {
                list += '<tr><td>' + arrStudent[i].id + '</td>' +
                    '<td>' + arrStudent[i].clazz + '</td>' +
                    '<td>' + arrStudent[i].name + '</td>' +
                    '<td>' + arrStudent[i].gender + '</td>' +
                    '<td>' + arrStudent[i].age + '</td>' +
                    '<td>' + arrStudent[i].tel + '</td>' +
                    '<td>' + arrStudent[i].hobby + '</td>' +
                    '<td>' + arrStudent[i].address + '</td>' +
                    '<td>' + arrStudent[i].remark + '</td>' +
                    '<td>' + arrStudent[i].date + '</td>' +
                    '<td><a href="#" class="btn1">修改</a>' + "" +
                    '<a href="#" class="btn2">删除</a></td></tr>'
            }
        }
        tBody.innerHTML = list;
        var btn2 = document.querySelectorAll('.btn2');
        del(btn2);
    }
    xhr.send(null);
}


// var table = document.querySelector('table');
function del(ele) {
    for (i = 0; i < ele.length; i++) {
        ele[i].index = i;
        ele[i].onclick = function () {
            tBody.removeChild(ele[this.index].parentNode.parentNode);
        }
    }
}


