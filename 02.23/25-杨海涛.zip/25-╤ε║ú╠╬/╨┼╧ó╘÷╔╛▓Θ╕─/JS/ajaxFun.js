var tBody = document.querySelector('.Tbody');
var Text = document.querySelector('.Text');
var btn = document.querySelector('.btn');
var btn2 = document.querySelectorAll('.btn2');

var baseUrl = 'http://localhost:3008/';
GetData(baseUrl + 'api/student/getStudent', '', showData);

function showData(xhr) {

    var arrStudent = JSON.parse(xhr.responseText);
    console.log(arrStudent)
    var list = '';
    for (var i = 0; i < arrStudent.length; i++) {
        list += `<tr>
        <td>${arrStudent[i]._id}</td>
        <td>${arrStudent[i].clazz}</td>
        <td>${arrStudent[i].name}</td>
        <td>${arrStudent[i].gender}</td>
        <td>${arrStudent[i].age}</td>
        <td>${arrStudent[i].tel}</td>
        <td>${arrStudent[i].hobby}</td>
        <td>${arrStudent[i].address}</td>
        <td>${arrStudent[i].remark}</td>
        <td>${arrStudent[i].date.split("T")[0]}</td>
        <td><a href="./page/ajax修改.html?id=${arrStudent[i]._id}" class="btn1" data-stud-id="${arrStudent[i].id}">修改</a>
        <a href="javascript:void(0)" class="btn2" id="${arrStudent[i]._id}">删除</a></td></tr>`
        
    }
    tBody.innerHTML = list;
    del();
}

btn.onclick = function () {
    // var nameValue = Text.value;
    // console.log(nameValue);
    var nameValue = Text.value.trim();
    console.log(nameValue)
    GetData(baseUrl + 'api/student/getStudent', { name: nameValue }, showData);
}


// 删除
function del() {
    var btn2 = document.querySelectorAll('.btn2');
    for (i = 0; i < btn2.length; i++) {
        btn2[i].onclick = function (e) {
            console.log({_id: this.id})
            // tBody.removeChild(ele[this.index].parentNode.parentNode);
            GetData(baseUrl + `api/student/removeStudent`,{_id: this.id},function() {
                e.target.parentNode.parentNode.remove();
            })
            e.target.parentNode.parentNode.remove();
        }
    }
}
