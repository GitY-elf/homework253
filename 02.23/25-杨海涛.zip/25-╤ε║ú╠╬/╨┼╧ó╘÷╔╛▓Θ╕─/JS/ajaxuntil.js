
//get请求
function GetData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    // console.log(dataObj(data))
    xhr.open('GET', url + '?' + dataObj(data));
    xhr.send(null);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        }

    }
}

// 转换窗体格式
function dataObj(obj) {
    if (!obj) {
        return;
    };
    var arrtemp = [];
    // 遍历对象for...in
    for (var key in obj) {
        var value = obj[key].toString();
        arrtemp.push(key + '=' + value);
    };
    return arrtemp.join('&');
};


//post请求
function postData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.setRequestHeader('Content-Type', 'application/json');
    var dataJson = JSON.stringify(data);
    xhr.send(dataJson);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    };
};