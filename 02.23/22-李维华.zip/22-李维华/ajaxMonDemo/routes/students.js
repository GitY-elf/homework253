const express = require('express');
var router = express.Router();

// 引入连接数据库的代码

require('../db/db.js');

let userschema = require('../db/userschma');

// 查询学生
router.get('/getStudent', (req, res) => {
    console.log(
        req.query
    );
    if (req.query.name) {
        userschema.find({ name: req.query.name }).then((data) => {
            res.status(200).send(data);
        });
    } else if (req.query.id) {
        userschema.find({ id: req.query.id }).then((data) => {
            res.status(200).send(data);
        });
    } else {
        userschema.find().then((data) => {
            res.status(200).send(data);
            // console.log(data);
        });
    }

});


// 创建学生并添加

router.post('/addStudent', (req, res) => {
    // 添加id
    req.body.id = Date.now().toString();
    console.log(req.body);
    userschema.create(req.body).then((rel) => {
        console.log(rel);
        res.status(200).send();
    });

});


// 删除数据
router.get('/removeStudent', (req, res) => {
    console.log(req.query.id);
    // 通过id获取信息进行删除
    userschema.deleteOne({ id: req.query.id }).then((rel) => {
        console.log(rel);
        res.status(200).send();
    });

});



// 更新数据
router.post('/updateStudent', function(req, res) {
    console.log(req.body);
    // 通过id获取信息进行更新
    userschema.updateOne({ id: req.body.id }, req.body).then((rel) => {
        console.log(rel);
        res.status(200).send();
    });

})



// module.exports 提供了暴露接口的方法
module.exports = router;