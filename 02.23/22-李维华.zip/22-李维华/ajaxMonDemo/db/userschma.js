const mongoose = require('mongoose');


// 创建规则
const userSchema = new mongoose.Schema({
    clazz: String,
    name: String,
    age: Number,
    tel: Number,
    address: String,
    remark: String,
    date: Date,
    gender: String,
    hobby: String,
    id: String
});


// 利用规则创建集合
const User = mongoose.model('User', userSchema);
// 暴露出去.使用User
module.exports = User