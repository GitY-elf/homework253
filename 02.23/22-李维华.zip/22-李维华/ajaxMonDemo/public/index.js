  // 获取元素
  // 搜索
  var btn = document.querySelector('button');
  // tbody
  var Tbody = document.querySelector('tbody');
  // ajax

  function getData(url, data, fun) {
      // 创建对象
      var xhr = new XMLHttpRequest();
      xhr.open('GET', url);
      // 发送
      xhr.send();
      // 监听状态的变化
      xhr.onreadystatechange = function() {
          if (xhr.readyState == 4 && xhr.status == 200) {
              console.log();
          };
      };
  };



  var xhr = new XMLHttpRequest();
  xhr.open('GET', 'http://localhost:3008/api/student/getStudent');
  xhr.send(null);
  xhr.onreadystatechange = function() {
          if (xhr.readyState == 4 && xhr.status == 200) {
              var arr = JSON.parse(xhr.responseText);
              console.log(arr);

              var Text = '';
              for (var i = 0; i < arr.length; i++) {
                  Text += `<tr><td> ${ arr[i].id} </td> 
                <td>${ arr[i].clazz }</td> 
                <td>${arr[i].name } </td> 
                <td>${arr[i].gender }</td> 
                <td> ${arr[i].age }</td> 
                <td> ${arr[i].tel} </td>
                <td> ${arr[i].hobby}</td>
                <td> ${arr[i].address} </td> 
                <td> ${ arr[i].remark }</td> 
                <td> ${arr[i].date.split("T")[0] }</td> 
                <td><a href="update.html?id=${ arr[i].id}" class="update"}>修改</a> 
                <a href="#" class="delete">删除</a></td></tr>`
              }
              Tbody.innerHTML = Text;
              // 删除
              DeleteFun();
          }
      }
      // 搜索
  btn.onclick = function() {
      var input = document.querySelector('input');
      var xhr = new XMLHttpRequest();
      xhr.open('GET', 'http://localhost:3008/api/student/getStudent?name=' + input.value);
      xhr.onreadystatechange = function() {
          if (xhr.readyState == 4 && xhr.status == 200) {
              // 转换成数组
              var arr = JSON.parse(xhr.responseText);
              console.log(arr);
              var Text = '';
              for (var i = 0; i < arr.length; i++) {
                  Text += `<tr><td> ${ arr[i].id} </td> 
                      <td>${ arr[i].clazz }</td> 
                      <td>${arr[i].name } </td> 
                      <td>${arr[i].gender }</td> 
                      <td> ${arr[i].age }</td> 
                      <td> ${arr[i].tel} </td>
                      <td> ${arr[i].hobby}</td>
                      <td> ${arr[i].address} </td> 
                      <td> ${ arr[i].remark }</td> 
                      <td> ${arr[i].date.split("T")[0] }</td> 
                      <td><a href="update.html?${ arr[i].id}" class="update">修改</a> 
                      <a href="#" class="delete">删除</a></td></tr>`
              }
              Tbody.innerHTML = Text;
              // 删除
              DeleteFun();
          }
      }
      xhr.send(null);
  }

  // 封装删除
  function DeleteFun() {
      var Delete = document.getElementsByClassName('delete');
      console.log(Delete);
      for (var i = 0; i < Delete.length; i++) {
          console.log(1);
          Delete[i].onclick = function(e) {
              console.log(111);
              var delId = e.target.parentNode.parentNode.firstElementChild.innerText;
              console.log(delId);
              getData(`http://localhost:3008/api/student/removeStudent?id=${delId}`);

              var flag = confirm('你确定删除?');
              if (flag) {
                  e.target.parentNode.parentNode.parentNode.removeChild(e.target.parentNode.parentNode);
                  console.log(1);
              }
          }
      }
  }



  //   var updateBtn = document.querySelectorAll('.update');
  //   console.log(updateBtn);
  //   for (var k = 0; k < updateBtn.length; k++) {
  //       // 绑定事件
  //       updateBtn[k].onclick = function() {
  //           console.log(this);
  //           console.log(this.dataset);
  //           localStorage.setItem('student', this.id);
  //       }
  //   }