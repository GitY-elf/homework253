function getData(url, data, fun) {
    // 创建对象
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    // 发送
    xhr.send();
    // 监听状态的变化
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    };
};

function postData(url, data, fun) {
    // 创建对象
    var xhr = new XMLHttpRequest();
    // 注意转换为post的时候url直接是接口地址
    xhr.open('POST', url);
    // 设置请求头
    xhr.setRequestHeader('Content-Type', 'application/json');
    var dataJson = JSON.stringify(data);
    // 发送
    xhr.send(dataJson);
    // 监听状态的变化
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    };
};
// 服务器接口的地址
var baseURL = 'http://localhost:3008';
// 获取form元素
var updateForm = document.querySelector('#update_form');
// 获取页面上的元素
var studInfo = document.querySelectorAll('.stud_info');
// 获取所有的性别元素
var gender = document.querySelectorAll('.gender');
// 获取所有的爱好的元素
var hobbies = document.querySelectorAll('.hobby');

var studUpdateId = decodeURI(location.search.split('?')[1]).split('=')[1];

// 通过以上操作获取数据
getData(baseURL + `/api/student/getStudent?id=${studUpdateId}`, null, function(xhr) {
    // 获取所有的数据设置到页面上

    var data = JSON.parse(xhr.responseText);
    console.log(data);
    var studUpdateObj = JSON.parse(xhr.responseText)[0];
    console.log(studUpdateId);
    console.log(xhr.responseText);
    for (var i = 0; i < studInfo.length; i++) {
        studInfo[i].value = studUpdateObj[studInfo[i].name];
    };
    // 性别的信息的设置
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].value == studUpdateObj.gender) {
            gender[j].checked = true;
        };
    };
    // 爱好的设置
    for (var k = 0; k < hobbies.length; k++) {
        if (studUpdateObj.hobby.includes(hobbies[k].value)) {
            hobbies[k].checked = true;
        };
    };
});


// 学生的总数据
var allStudInfo = {};
updateForm.onsubmit = function(e) {
    // 页面上可以通过value值直接得到的数据
    for (var i = 0; i < studInfo.length; i++) {
        allStudInfo[studInfo[i].name] = studInfo[i].value;
    };
    // 性别的信息的获取
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStudInfo.gender = gender[j].value;
            break;
        };
    };
    // 所有的爱好的信息获取
    var tempHobby = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempHobby.push(hobbies[k].value);
        }
    };
    allStudInfo.hobby = tempHobby.join();
    // 设置学生数据对象的id值
    allStudInfo.id = studUpdateId;
    // 发送post请求，添加数据
    console.log(allStudInfo);
    postData(baseURL + '/api/student/updateStudent', allStudInfo, function() {
        // 包含页面来源的域名
        location.href = 'index.html';
    });
    // 阻止默认行为,提交表单,并刷新页面
    e.preventDefault();
}