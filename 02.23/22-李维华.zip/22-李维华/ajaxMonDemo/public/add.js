var formBtn = document.querySelector('#form_btn');
var studInfo = document.querySelectorAll('.stud_info');
var gender = document.querySelectorAll('.gender');
var hobbies = document.querySelectorAll('.hobby');
var allstudInfo = {};

function postData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open('post', url);
    xhr.setRequestHeader('Content-Type', 'application/json');
    var dataJson = JSON.stringify(data);
    console.log(dataJson);
    xhr.send(dataJson);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        }
    }
}

formBtn.onsubmit = function() {
    for (var i = 0; i < studInfo.length; i++) {
        allstudInfo[studInfo[i].name] = studInfo[i].value;
    }
    // 性別的获取
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allstudInfo.gender = gender[j].value;
            break;
        }
    }
    // 爱好的获取
    var tempHobby = [];
    for (k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempHobby.push(hobbies[k].value);
        }
    }
    allstudInfo.hobby = tempHobby.join();

    console.log(allstudInfo);
    postData('http://localhost:3008/api/student/addStudent', allstudInfo, function() {
        location.href = location.origin + '/index.html';
    })
    return false;
}