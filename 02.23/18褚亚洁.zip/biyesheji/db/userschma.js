// 1.引入mongoose模块
const mongoose = require('mongoose');
// 创建集合规则
const userSchema = new mongoose.Schema({
    name: String,
    age: Number,
    gender: String,
    clazz: String,
    tel: String,
    hobby: String,
    address: String,
    remark: String,
    date: String
});

// 利用规则创建集合
const User = mongoose.model('User', userSchema);
// 暴露出去.使用User
module.exports = User