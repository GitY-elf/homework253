var express = require('express');
// const User = require('../db/userschma');
var router = express.Router();

// 引入连接数据库的代码
require('../db/db.js');
let userschma = require('../db/userschma');

// 查询学生
router.get('/getStudent', function(req, res) {
    if (req.query.name) {
        userschma.find({ "name": req.query.name }).then((date) => {
            res.status(200).send(date);
        })
    }
    userschma.find().then((data) => {
        res.status(200).send(data);
    });
});
// 添加学生信息
router.post('/addStudent', (req, res) => {
    // console.log(req.body);
    userschma.create(req.body).then((rel) => {
        console.log(rel);
        res.status(200).send();
    });
});
// 删除学生信息
router.get('/removeStudent', function(req, res) {
    userschma.deleteOne({ _id: req.query._id }).then((rel) => {
        console.log(rel);
    });
});
// 修改学生信息
router.post('/updateStudent', (req, res) => {
    // console.log(req.body);
    userschma.updateOne({ "_id": req.body.id }, req.body).then((rel) => {
        console.log(rel);
        res.status(200).send();
    })
});
// module.exports 提供了暴露接口的方法
module.exports = router;