// 服务器接口的地址
var baseURL = 'http://localhost:3008';
// 获取form元素
var updateForm = document.querySelector('#update_form');
// 获取页面上的元素
var studInfo = document.querySelectorAll('.stud_info');
// 获取所有的性别元素
var gender = document.querySelectorAll('.gender');
// 获取所有的爱好的元素
var hobbies = document.querySelectorAll('.hobby');

// 从页面的url中取出id值,获取学生的数据渲染到页面上?id=999999
var studUpdateId = location.search.split('=')[1];

// 通过以上操作获取数据
getData(baseURL + '/api/student/getStudent', { id: studUpdateId }, function(xhr) {
    // 获取所有的数据设置到页面上
    var studUpdateObj = JSON.parse(xhr.responseText)[0];
    console.log(studUpdateId);
    for (var i = 0; i < studInfo.length; i++) {
        studInfo[i].value = studUpdateObj[studInfo[i].name];
    };
    // 性别的信息的设置
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].value == studUpdateObj.gender) {
            gender[j].checked = true;
        };
    };
    // 爱好的设置
    for (var k = 0; k < hobbies.length; k++) {
        if (studUpdateObj.hobby.includes(hobbies[k].value)) {
            hobbies[k].checked = true;
        };
    };
});


// 学生的总数据
var allStudInfo = {};
updateForm.onsubmit = function(e) {
    // 页面上可以通过value值直接得到的数据
    for (var i = 0; i < studInfo.length; i++) {
        allStudInfo[studInfo[i].name] = studInfo[i].value;
    };
    // 性别的信息的获取
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStudInfo.gender = gender[j].value;
            break;
        };
    };
    // 所有的爱好的信息获取
    var tempHobby = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            tempHobby.push(hobbies[k].value);
        }
    };
    allStudInfo.hobby = tempHobby.join();
    // 设置学生数据对象的id值
    allStudInfo.id = studUpdateId;
    // 发送post请求，添加数据
    console.log(allStudInfo);
    postData(baseURL + '/api/student/updateStudent', allStudInfo, function() {
        // 包含页面来源的域名
        location.href = location.origin + '/index.html';
    });
    // 阻止默认行为,提交表单,并刷新页面
    e.preventDefault();
}