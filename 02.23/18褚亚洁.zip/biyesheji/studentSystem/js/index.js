// 获取元素
var stuBody = document.querySelector('#tbody_stu');
// 服务器接口的地址
var baseURL = 'http://localhost:3008';
// 创建对象
var xhr = new XMLHttpRequest();
// 通过open方法
xhr.open('GET', baseURL + '/api/student/getStudent');
// send发送
xhr.send(null);
// 监听http状态的变化(异步方法)
xhr.onreadystatechange = function() {
    // 根据状态的变化来获取数据
    if (xhr.readyState == 4 && xhr.status == 200) {
        // 获取后台传回的数据
        var studentData = JSON.parse(xhr.responseText);
        // 设置到页面上的数据
        var relDataHtml = '';
        for (var i = 0; i < studentData.length; i++) {
            // 拼接好的内容
            relDataHtml += `<tr>
            <td>${studentData[i].id}</td>
            <td>${studentData[i].clazz}</td>
            <td>${studentData[i].name}</td>
            <td>${studentData[i].gender}</td>
            <td>${studentData[i].age}</td>
            <td>${studentData[i].tel}</td>
            <td>${studentData[i].hobby}</td>
            <td>${studentData[i].address}</td>
            <td>${studentData[i].remark}</td>
            <td>${studentData[i].date}</td>
            <td><a href="#" class="update_btn">修改</a><a href="#" class="delete_btn">删除</a></td></tr>`
        };
        // 当没有数据时,添加到页面
        if (!relDataHtml) {
            relDataHtml = `<tr><td colspan="11">没有查询到数据</td></tr>`
        };
        stuBody.innerHTML = relDataHtml;
    }
};

// 搜索功能
var searchValue = document.querySelector('#searchvalue');
var searchBtn = document.querySelector('#search_btn');
// 绑定搜索事件
searchBtn.onclick = function() {
    // 搜索的值的格式验证
    var stuValue = searchValue.value.trim();
    // 创建对象
    var xhr = new XMLHttpRequest();
    // 通过open方法
    xhr.open('GET', baseURL + '/api/student/getStudent' + '?name=' + stuValue);
    // send发送
    xhr.send(null);
    // 监听http状态的变化(异步方法)// 监听http状态的变化(异步方法)
    xhr.onreadystatechange = function() {
        // 根据状态的变化来获取数据
        if (xhr.readyState == 4 && xhr.status == 200) {
            // 获取后台传回的数据
            var studentData = JSON.parse(xhr.responseText);
            // 设置到页面上的数据
            var relDataHtml = '';
            for (var i = 0; i < studentData.length; i++) {
                // 拼接好的内容
                relDataHtml += `<tr>
            <td>${studentData[i].id}</td>
            <td>${studentData[i].clazz}</td>
            <td>${studentData[i].name}</td>
            <td>${studentData[i].gender}</td>
            <td>${studentData[i].age}</td>
            <td>${studentData[i].tel}</td>
            <td>${studentData[i].hobby}</td>
            <td>${studentData[i].address}</td>
            <td>${studentData[i].remark}</td>
            <td>${studentData[i].date}</td>
            <td><a href="#" class="update_btn">修改</a><a href="#" class="delete_btn">删除</a></td></tr>`
            };
            // 当没有数据时,添加到页面
            if (!relDataHtml) {
                relDataHtml = `<tr><td colspan="11">没有查询到数据</td></tr>`
            };
            stuBody.innerHTML = relDataHtml;
        }
    }
};