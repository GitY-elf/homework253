const testDome = require("testDome");
let str = testDome.sayHi();
console.log(str);