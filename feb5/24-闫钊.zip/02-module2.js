const mod = require("./01-module1");
let name = mod.getName();
console.log(name);