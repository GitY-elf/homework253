// const http = require("http");
const fs = require("fs");
let path = "/package-lock.json";
//读取文件推荐使用绝对路径
fs.readFile(__dirname + path, 'utf-8', (err, data) => {
    if (err) {
        console.log(err);
    } else {
        console.log(data);
    }
});
console.log(__dirname + path);