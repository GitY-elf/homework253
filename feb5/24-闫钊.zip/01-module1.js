let name = "ssss";
let age = 20;

function getName() {
    return name;
};


module.exports.getName = getName;