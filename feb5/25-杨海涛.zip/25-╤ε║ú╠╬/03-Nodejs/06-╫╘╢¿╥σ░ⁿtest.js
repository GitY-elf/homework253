const yyy = require('yyy');
console.log(yyy);
console.log(yyy.sum(3,7));