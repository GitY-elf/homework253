let module1 = require('./02-module1.js');
console.log(module1.uname);