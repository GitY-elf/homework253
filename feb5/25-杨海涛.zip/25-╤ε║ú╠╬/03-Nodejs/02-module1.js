let uname = 'zhangmeili';
let age = 18;
let person = {
    gender: false
};


module.exports.uname = uname;
module.exports.person = person;

// 不建议
// exports.uname = uname;

// 导出多个
module.exports = {
    uname: uname,
    age: age,
    person: person
}
