const md5 = require('md5-node');

// 第三方模块可以从node_module文件夹中进行加载
const text = require('yht/text');
console.log(text);