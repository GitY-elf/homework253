let fs = require('fs');
// 文件绝对路径
console.log(__dirname);
console.log(__filename);
fs.readFile(__dirname + './files/1.txt','utf-8',(err,data) => {
    if(err) {
        console.log(err);
    } else {
        console.log(data);
    }
})