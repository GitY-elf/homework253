// let mytool = require('mytool');

// console.log(mytool);
// console.log(mytool.add(1, 2));


// let mytool = require('mytool');

// console.log(mytool);
// console.log(mytool.add(1, 2));


let mytool = require('mytool');

console.log(mytool);
console.log(mytool.add(1, 2));