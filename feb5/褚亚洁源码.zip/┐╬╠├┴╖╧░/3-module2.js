// var module1 = require('./2-module1.js');
// console.log(module1.firstName);
// console.log(module1.age);
// console.log(module1.getAge);



// var module1 = require('./2-module1.js');
// console.log(module1.firstName);
// console.log(module1.age);
// console.log(module1.getAge);




var module1 = require('./2-module1.js');
console.log(module1.firstName);
console.log(module1.age);
console.log(module1.getAge);