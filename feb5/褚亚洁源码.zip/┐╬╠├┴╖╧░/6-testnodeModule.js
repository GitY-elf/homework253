const lodash = require('lodash');
const md5 = require('md5-node');
// const momoko = require('momoko')
const momoko = require('momoko.js');
console.log(momoko);