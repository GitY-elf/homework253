// let firstName = '张美丽';
// let age = 19;
// // 定义方法
// function getAge() {
//     return age
// }
// // console.log(module.exports);
// // 暴露出去
// // module.exports.firstName = firstName;
// // module.exports.age = age;
// // module.exports.getAge = getAge;
// // 空对象
// // module.exports = {};
// // module.exports和exports共同指向同一个对象
// // exports.firstName = firstName;
// // exports.age = age;
// // exports.getAge = getAge;
// // 如果重新为exports和module.exports重新赋值以如果为module.exports优先
// // exports = {
// //     age: age
// // };
// // module.exports = {
// //     firstName: firstName
// // }
// // 导出多个内容
// exports = module.exports = {
//     firstName: firstName,
//     age: age,
//     getAge: getAge
// }





// let firstName = '张美丽';
// let age = 19;
// // 定义方法
// function getAge() {
//     return age
// }
// // console.log(module.exports);
// // 暴露出去
// // module.exports.firstName = firstName;
// // module.exports.age = age;
// // module.exports.getAge = getAge;
// // 空对象
// // module.exports = {};
// // module.exports和exports共同指向同一个对象
// // exports.firstName = firstName;
// // exports.age = age;
// // exports.getAge = getAge;
// // 如果重新为exports和module.exports重新赋值以如果为module.exports优先
// // exports = {
// //     age: age
// // };
// // module.exports = {
// //     firstName: firstName
// // }
// // 导出多个内容
// exports = module.exports = {
//     firstName: firstName,
//     age: age,
//     getAge: getAge
// }






let firstName = '张美丽';
let age = 19;
// 定义方法
function getAge() {
    return age
}
// console.log(module.exports);
// 暴露出去
// module.exports.firstName = firstName;
// module.exports.age = age;
// module.exports.getAge = getAge;
// 空对象
// module.exports = {};
// module.exports和exports共同指向同一个对象
// exports.firstName = firstName;
// exports.age = age;
// exports.getAge = getAge;
// 如果重新为exports和module.exports重新赋值以如果为module.exports优先
// exports = {
//     age: age
// };
// module.exports = {
//     firstName: firstName
// }
// 导出多个内容
exports = module.exports = {
    firstName: firstName,
    age: age,
    getAge: getAge
}