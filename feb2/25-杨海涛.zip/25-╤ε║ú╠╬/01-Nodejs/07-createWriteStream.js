let fs = require('fs');
let data = 'Today is a sunny day! \n';
// 创建写入流
var cws = fs.createWriteStream('./files/3.txt');
for (var i = 0; i < 15; i++) {
    // 写入
    cws.write(data);
}
// 结束
cws.end();
// 监听完成
cws.on('finish', () => {
    console.log('写入完成');
})