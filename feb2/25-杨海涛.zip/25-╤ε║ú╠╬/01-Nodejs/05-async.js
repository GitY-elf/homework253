let fs = require('fs');
let read = function(filename) {
    return new Promise((resolve,reject) => {
        fs.readFile(filename,'utf8',(err,data) => {
            if(err) {
                reject(err);
            } else {
                resolve(data)
            }
        })
    })
}
async function reads() {
    let files1 = await read('./files/1.txt');
    let files2 = await read('./files/2.txt');
    let files3 = await read('./files/3.txt');

    // 文件里的内容
    console.log(files1);  
    console.log(files2);
    console.log(files3);
};
reads();