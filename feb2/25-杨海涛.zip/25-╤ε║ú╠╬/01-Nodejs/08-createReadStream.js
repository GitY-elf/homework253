let fs = require('fs');
let crw = fs.createReadStream('./files/3.txt');
// 保存读取数据
let str = '';
// data: 读取数据
crw.on('data', (datastr) => {
    str += datastr;
});
// 读取完成后，打印出来
crw.on('end', () => {
    console.log(str);
})