// fs: file System 文件系统

// 引入模块
let fs = require('fs');
// console.log(fs);

// 读取文件： fs.readFile()
// fs.readFile('./files/1.txt','utf-8',(err, data) => {
//     if(err) {
//         console.log(err);
//     } else {
//         console.log(data);
//         // 如果不加 utf-8, 就出现buffer(一种数据类型，专门临时存储一些二进制数据) 
//         // console.log(data.toString());
//     }
// })

// 写入文件：writeFile()    （信息重置）
// 如果没有这个文件就自动创建，再写入
// fs.writeFile('./files/2.txt','hello World !',(err) => {
//     if(err) {
//         console.log(err);
//     } else {
//         console.log('写入成功');
//     }
// });

// 追加文件内容  appendFile()
// fs.appendFile('./files/2.txt',' Today is a sunny day !',(err) => {
//     if(err) {
//         console.log(err);
//     } else {
//         console.log('追加成功');
//     }
// })

// 删除文件：unlink(文件路径，回调)
// fs.unlink('./files/3.txt',(err) => {
//     if(err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// })

// 重命名：rename()
fs.rename('./files/3.txt','./files/rename.txt',(err) => {
    if(err) {
        console.log(err);
    } else {
        console.log('重命名成功');
    }
})