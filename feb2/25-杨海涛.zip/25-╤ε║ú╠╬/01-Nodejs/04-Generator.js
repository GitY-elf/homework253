let fs = require('fs');
let read = function(filename) {
    return new Promise((resolve,reject) => {
        fs.readFile(filename,'utf8',(err,data) => {
            if(err) {
                reject(err);
            } else {
                resolve(data);
            }
        })
    })
}
let rename = function(oldFilename,newFilename) {
    return new Promise((resolve,reject) => {
        fs.rename(oldFilename,newFilename,err => {
            if(err) {
                reject(err);
            } else {
                resolve('重命名成功');
            }
        })
    })
}

function* reads() {
    yield read('./files/1.txt')
    yield read('./files/2.txt')
    yield read('./files/3.txt')
}

var rel = reads();
rel.next().value.then(data => {
    console.log(data);
    return rel.next().value;
}).then(data => {
    console.log(data);
    return rel.next().value;
}).then(data => {
    console.log(data);
})