let fs = require('fs')

// 文件读取
let read = function (filename) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, 'utf8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });
};
// 重命名文件
let rename = function (oldfileName, newfileName) {
    return new Promise((resolve, reject) => {
        fs.rename(oldfileName, newfileName, err => {
            if (err) {
                reject(err);
            } else {
                resolve('重命名成功');
            }
        });
    });
};
read('./files/1.txt').then((data) => {
    console.log(data);
    return read('./files/1.txt');
}).then((data) => {
    console.log(data);
    return rename('./files/rename.txt','./files/name.txt')
}).then((data) => {
    console.log(data);
})