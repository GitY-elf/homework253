let fs = require('fs');
// 判断是文件还是目录
// fs.stat('./files',(err,stats) => {
//     if(err) {
//         console.log(err);
//     } else {
//         if(stats.isDirectory()) {
//             console.log('这是一个目录');
//         } else if(stats.isFile()) {
//             console.log('这是一个文件');
//         }
//     }
// })

// // 创建文件夹
// fs.mkdir('./files/text',(err) => {
//     if(err) {
//         console.log(err);
//     } else {
//         console.log('文件夹创建成功');
//     }
// })

// // 写入文件
// fs.writeFile('./files/text/11.txt','12306,12315',err => {
//     if(err) {
//         console.log(err);
//     } else {
//         console.log('文件创建成功');
//     }
// })

// // 读取文件夹
// fs.readdir('./files/text',(err,files) => {
//     if(err) {
//         console.log(err);
//     } else {
//         console.log(files);
//     }
// })

// 删除 空文件夹
fs.rmdir('./files/text',err => {
    if(err) {
        console.log(err);
    } else {
        console.log('删除成功');
    }
})

