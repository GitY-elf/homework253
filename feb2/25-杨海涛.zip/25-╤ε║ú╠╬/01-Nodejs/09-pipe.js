let fs = require('fs');
// 写入流
let cws = fs.createWriteStream('./files/text/11.txt');
// 读取流
let crs = fs.createReadStream('./files/text/22.txt');
// 读取流的方法
crs.pipe(cws);
// 结束
crs.on('end',() => {
    console.log('读取完成');
});