//promise解决异步读取文件

const fs = require("fs");

//创建一个读取文件的方法
let readFile = function(path) {
    return new Promise((resolve, reject) => {
        fs.readFile(path, "utf-8", (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data)
            };
        });
    });
};

//执行readFile方法,调用promise的then方法
// readFile("./files/2.txt").then((data) => {
//     console.log(data);
// });

//读取多个文件
readFile("./files/2.txt").then((data) => {
    console.log(data);
    return readFile("./files/3.txt");
}).then((data) => {
    console.log(data);
})