// 如何删除一个不是空的文件夹
const fs = require("fs");

// //删除一个文件
// let delFile = function(path) {
//     fs.unlink(path, (err) => {
//         if (err) {
//             console.log("err 删除文件");
//         } else {
//             console.log("删除文件成功");
//         };
//     });
// };

// //删除一个文件夹
// let delDir = function(path) {
//     fs.rmdir(path, (err) => {
//         if (err) {
//             console.log("err 删除文件夹");
//         } else {
//             console.log("删除一个文件夹");
//         }
//     })
// };

// //读取一个文件夹
// async function redDir(path) {
//     await fs.readdir(path, {
//         withFileTypes: true
//     }, (err, files) => {
//         if (err) {
//             console.log("err 读取文件夹");
//         } else {
//             //判断这个文件夹中有没有文件
//             if (files.length) {
//                 files.forEach((value) => {
//                     //判断这个文件是否为文件夹
//                     if (value.isFile()) {
//                         //是文件就删除
//                         delFile(path + "/" + value.name);
//                     } else {
//                         //是文件夹就读取这个文件
//                         redDir(path + "/" + value.name);
//                     }
//                 });
//             };
//             //文件夹中没有文件就删除这个文件夹

//         };
//     });
//     await delDir(path);
// };

// redDir("./files");

fs.rmdir("./files", {
    recursive: true
}, (err) => {
    if (err) {
        console.log("删除失败!");
    } else {
        console.log("删除成功");
    }
})