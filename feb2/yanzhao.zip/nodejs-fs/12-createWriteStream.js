//创建写入通道
const fs = require("fs");

let str = "nihao a a sdknaksjdh kjahsfajkshf";
let cws = fs.createWriteStream("./files/hello.txt");
cws.write(str);
cws.end();
cws.on("finish", (err) => {
    if (err) {
        console.log(err);
    }
})