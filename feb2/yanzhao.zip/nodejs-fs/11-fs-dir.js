//dir对文件夹的操作
const fs = require("fs");

//创建一个文件夹
// fs.mkdir("./css", (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log("创建成功");
//     }
// });

//删除一个文件夹
// fs.rmdir("./css", (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log("删除文件夹成功");
//     };
// });

//查看文件夹的文件
fs.readdir("./files", {
    withFileTypes: true
}, (err, files) => {
    if (err) {
        console.log(err);
    } else {
        files.forEach((value) => {
            if (value.isFile()) {
                console.log(value.name);
            } else if (value.isDirectory()) {
                console.log("文件夹");
            }
        })
    };
});

// 如何删除一个不是空的文件夹