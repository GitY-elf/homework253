//通道  读取流和输入流
const fs = require("fs");

//创建一个输入流
let cws = fs.createWriteStream("./files/hello2.txt");

//创建一个读取流
let crs = fs.createReadStream("./files/hello.txt");

// 读取流的pipe
crs.pipe(cws);
crs.on("end", () => {
    console.log("结束了");
})