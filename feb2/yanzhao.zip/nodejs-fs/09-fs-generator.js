//利用generator解决异步方法
const fs = require("fs");

//读取文件的方法
let readFile = function(path) {
    return new Promise((resolve, reject) => {
        fs.readFile(path, "utf-8", (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            };
        });
    });
};

//创建generator方法
function* read() {
    yield readFile("./files/2.txt");
    yield readFile("./files/3.txt");
    yield readFile("./files/name.txt");
}
let rel = read();

rel.next().value.then((data) => {
    console.log(data);
});
rel.next().value.then((data) => {
    console.log(data);
});
rel.next().value.then((data) => {
    console.log(data);
});