const fs = require("fs");
//创建一个文件夹
fs.mkdir("./files/css", (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("mkdir ok");
    }
});

//读取文件夹里面的文件
// fs.readdir("./files", (err, files) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log(files);
//     }
// });

//删除一个空的文件夹
// fs.rmdir("./files/css", (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log("删除目录成功");
//     }
// });