const fs = require("fs");
// async配合await

let readFile = function(path) {
    return new Promise((resolve, reject) => {
        fs.readFile(path, "utf-8", (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            };
        });
    });
};

async function read() {
    let file1 = await readFile("./files/2.txt");
    let file2 = await readFile("./files/3.txt");
    let file3 = await readFile("./files/name.txt");
    console.log(file1);
    console.log(file2);
    console.log(file3);
}

read();