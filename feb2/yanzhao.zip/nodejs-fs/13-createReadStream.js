//创建读取通道
const fs = require("fs");
let crs = fs.createReadStream("./files/hello.txt");
let str = "";
crs.on("data", (dataStr) => {
    str += dataStr;
})

crs.on("end", () => {
    console.log(str);
});

crs.on("error", (error) => {
    console.log(error);
})