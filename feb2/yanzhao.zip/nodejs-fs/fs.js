const { request } = require("http");

const fs = require("fs");

//读取文件
fs.readFile("./files/1.txt", 'utf-8', (err, data) => {

    if (err) {
        console.log(err);
    } else {
        console.log(data)
    };
});

//写入文件,没有就创建一个新的,有的就覆盖掉
fs.writeFile("./files/2.txt", "This is new file,hello world", "utf-8", (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("写入文件成功");
    }
});

//给文件追加内容,没有文件就创建一个新的,有文件在已有的文件追加内容
fs.appendFile("./files/3.txt", "---这是追加的内容 ", "utf-8", (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("追加文本成功");
    }
});

//重新命名
fs.rename("./files/rename.txt", "./files/name.txt", (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("重命名文件成功");
    }
});

//删除文件
fs.unlink("./files/1.txt", (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("删除文件成功");
    }
});