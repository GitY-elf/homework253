const fs = require("fs");

let readFile = function(path) {
    return new Promise((resolve, reject) => {
        fs.readFile(path, "utf-8", (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            };
        });
    });
};

async function read() {
    let read1 = await readFile("./files/2.txt")
    let read2 = await readFile("./files/3.txt")
    let read3 = await readFile("./files/name.txt")
    console.log(read1);
    console.log(read2);
    console.log(read3);
};

read();