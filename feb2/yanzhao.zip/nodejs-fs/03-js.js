const fs = require("fs");
//同步执行的读取文件

//如果有异常用try{}catch{}捕获异常进行抛出
try {
    let rel = fs.readFileSync("./02-fs.js", 'utf-8');
    console.log(rel);
} catch (error) {
    console.log(error);
}