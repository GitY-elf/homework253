//先读取文件再重命名
const { promises } = require("dns");
const fs = require("fs");

let read = function() {
    return new Promise((resolve, reject) => {
        fs.readFile("./files/2.txt", "utf-8", (err, data) => {
            if (err) {
                reject(err)
            } else {
                resolve(data)
            }
        })
    })
};
read().then((data) => {
    console.log(data);
});