//fs file sysytem 文件系统
//读取文件,写入文件,追加内容,删除文件,重命名文件

let fs = require("fs");
// 读取一个文件
// fs.readFile('hello.txt', 'utf-8', (err, data) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log(data);
//     }
// });


// 读取文件 fs.readFile(path[, options], callback)
// 写入文件 fs.writeFile(file, data[, options], callback)
// 追加内容 fs.appendFile(path, data[, options], callback)
// 删除文件 fs.unlink(path, callback)
// 重命名文件...... fs.rename(oldPath, newPath, callback)

// 写入数据到文件中,不覆盖原来的内容,添加新的内容到文本的后面,如果文件不存在就创建这个文件
// fs.appendFile("hello.txt", "\n这是追加进来的数据", "utf-8", (err, data) => {
//     if (err) { console.log(err); } else {
//         console.log(data);
//     }
// });

//写入一个文件,如果存在就覆盖,不存在就创建
fs.writeFile("text.txt", "this is hello world!", (err, data) => {
    if (err) {
        console.log(err);
    } else {
        console.log(data);
    }
});

// //修改文件的名字
fs.rename("text.txt", "hello.txt", (err, data) => {
    if (err) {
        console.log(err);
    } else {
        console.log(data);
    }
})

// //读取文件的内容
fs.readFile('./hello.txt', "utf-8", (err, data) => {
    console.log("读取到的数据");
    console.log(data);
});


//删除文件
fs.unlink("text.txt", (err, data) => {
    if (err) {
        console.log(err);
    } else {
        console.log(data);
    }
});