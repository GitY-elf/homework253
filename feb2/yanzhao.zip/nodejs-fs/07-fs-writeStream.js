const fs = require("fs");
//创建一个写入流
let rel = fs.createWriteStream("./files/4.txt");
rel.write("hellow");
rel.end();
console.log(rel);