let fs = require("fs");
// console.log(fs);
// 文件系统
// 1.读取文件
//2. 写入文件
// 3.追加内容
//4. 删除文件
//5. 重命名文件





// 读取文件 fs.readfile();
// fs.readFile("./files/1.text", (err, data) => {
//     if (err) {
//         console.log(err);
//     } else {
// buffer  是一种是一种数据暂时储存区  用来临时存储一些数据
//         console.log(data.toString());
//     }
// });


fs.readFile("./files/1.text", "utf-8", (err, data) => {
    if (err) {
        console.log(err);
    } else {
        console.log(data);
    }
});