// 删除


let fs = require("fs");
// console.log(fs);
fs.unlink("./files/03-append.text", (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('已删除文件');
    }
});