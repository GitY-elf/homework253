// 写入文件

let fs = require("fs");
// console.log(fs);
fs.writeFile("./files/02-write.text", ' 写入的数据啦啦啦啦', 'utf8', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('数据已写入到文件中');
    }
});