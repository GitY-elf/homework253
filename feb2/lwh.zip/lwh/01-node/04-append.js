// 追加文本


let fs = require("fs");
// console.log(fs);
fs.appendFile("./files/03-append.text", '           追加的数据', 'utf8', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('数据已被追加到文件');
    }
});