// 重明名
let fs = require("fs");
// console.log(fs);

fs.rename("./files/04-rename.text", './files/new.text', function(err) {
    if (err) {
        console.log(err);
    } else {
        console.log('已重名');
    }
})