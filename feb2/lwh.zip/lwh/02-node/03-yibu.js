let read = function(filename) {

}