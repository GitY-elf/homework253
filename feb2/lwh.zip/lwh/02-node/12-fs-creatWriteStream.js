let fs = require('fs');
let dataInfo = "132465你哈\n";
let cws = fs.createWriteStream(`./files/cw.text`);
// 写入




for (let i = 0; i < 500; i++) {
    cws.write(dataInfo);
}



// 写入结束
cws.end();
// 完成
cws.on('finish', () => {
    console.log(`写入文件完成`);
})