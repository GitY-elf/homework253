let fs = require("fs");

// 先读取文件  在重命名
// fs.readFile('./files/01-write.text', 'utf-8', (err, data) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log(data);
//     }
// });
// fs.rename('./files/rename.text', './files/name.text', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('重命名成功');
//     }
// });


// 读取文件  
let read = function(filename) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, 'utf-8', (err, data) => {
            if (err) {

                reject(err);
            } else {
                resolve(data);
            }
        });
    })
};

let rename = function(oldFile, newFile) {
    return new Promise((resolve, reject) => {
        fs.rename(oldFile, newFile, (err) => {
            if (err) {
                reject(err);
            } else {
                resolve('重命名成功');
            }
        });
    })
}


// 执行语句顺序 --先1   在  2  在重名

read(`./files/01-write.text`).then((data) => {
    console.log(data);
    return read('./files/02-append.text');
}).then((data) => {
    console.log(data);
    return rename('./files/rename.text', './files/name.text');
}).then((data) => {
    console.log(data);
});