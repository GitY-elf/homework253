// let fs = require("fs");
// // console.log(fs);
// fs.writeFile("./files/02-write.text", ' 写入的数据啦啦啦啦', 'utf8', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('数据已写入到文件中');
//     }
// });


let fs = require("fs");


// fs.writeFile('./files/01-write.text', "Boy is boy", (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log("写入成功");
//     }
// });



// fs.appendFile('./files/02-append.text', "Boy is boy", (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log("追加成功");
//     }
// });



// // 异步操作    :非柱塞操作
// // 删除文件

// fs.unlink('./files/del.text', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log("删除成功");
//     }
// });



// 重命名

fs.rename('./files/03-rename.text', './files/name.text', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("重命名成功");
    }
});