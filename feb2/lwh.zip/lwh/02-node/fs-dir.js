let fs = require('fs');

// stat(path,callback) 判定文件还是目录

// callback(err,stats)

// fs.stat('./files', (err, stats) => {
//     if (err) {
//         console.log(err);
//     } else {
//         if (stats.isDirectory()) {
//             console.log("是一个目录");
//         } else if (stats.isFile()) {
//             console.log("是文件");
//         }
//     }
// })


// ----------------------------------------------------------------
// 创建文件夹

// fs.mkdir("./files/css", (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('创建成功');
//     }
// })

// ----------------------------------------------------------------
// 删除文件夹

// fs.rmdir("./files/css", (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除文件夹成功');
//     }
// })






// -------------------------------------------------------------------------
// 读取文件夹

fs.readdir("./files", (err, files) => {
    if (err) {
        console.log(err);
    } else {
        // 返回值为数组
        console.log(files);
    }
})