let fs = require('fs');


let read = function(filename) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, 'utf-8', (err, data) => {
            if (err) {

                reject(err);
            } else {
                resolve(data);
            }
        });
    })
};

let rename = function(oldFile, newFile) {
    return new Promise((resolve, reject) => {
        fs.rename(oldFile, newFile, (err) => {
            if (err) {
                reject(err);
            } else {
                resolve('重命名成功');
            }
        });
    })
}


// 申明一个generator函数

function* readfi() {
    yield read('./files/01-write.text');
    yield read('./files/02-append.text');
    yield rename('./files/rename.text', './files/name.text');
}


// 用一个参数接受结果

let rel = readfi();

rel.next().value.then(data => {
    console.log(data);
    return rel.next().value;
}).then(data => {
    console.log(data);
    return rel.next().value;
}).then(data => {
    console.log(data);
})