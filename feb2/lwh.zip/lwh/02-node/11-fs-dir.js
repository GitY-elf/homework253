let fs = require('fs');

// 创建文件  递归创建
// fs.mkdir("css/index.css", {
//     recursive: true
// }, (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('创建成功');
//     }
// })




// 读取文件夹

fs.readdir("./files", { withFileTypes: true }, (err, files) => {
    if (err) {
        console.log(err);
    } else {
        // 返回值为数组  文件名
        console.log(files);
    }
})