let fs = require('fs');

let crs = fs.createReadStream(`./files/01-write.text`);

let cws = fs.createWriteStream('./files/02-append.text');

crs.pipe(cws);

crs.on("end", () => {
    console.log('读取完成');
})