let fs = require('fs');

let crw = fs.createReadStream(`./files/cw.text`);
// 保存读取的数据
let str = ``;


// 记录读取的次数

var flag = 0;

// data用于读取数据


crw.on('data', (daraStr) => {
    str += daraStr;
    flag++
})


crw.on('end', () => {
    console.log(str);
    console.log(flag);
})