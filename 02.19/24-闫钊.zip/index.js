//读取文件模块
const fs = require("fs");

//express框架
const express = require("express");

//express的实例 app
const app = express();

//设置静态资源
app.use(express.static(__dirname))

//获取POST请求的数据
const bodyParser = require("body-parser");

//设置POST请求的数据
app.use(express.urlencoded({ extended: false }));


//解决跨域
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "PUT,GET,POST,DELETE,OPTIONS");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header("Access-Control-Allow-Headers", "Content-Type");
    res.header("Content-Type", "application/json");
    next();
});

// localhost:3000/login
//getstudent  获取全部的学生信息
app.get("/getstudent", (req, res) => {
    fs.readFile(__dirname + "/data/student.json", "utf-8", (err, data) => {
        if (err) {
            res.status(404).send("没有找到数据");
            console.log(err);
        } else {
            res.status(200).send(data);
        };
    });
});

//addstudent  添加学生的信息
app.post("/addstudent", (req, res) => {
    fs.readFile(__dirname + "/data/student.json", "utf-8", (err, data) => {
        if (err) {
            console.log(err);
        } else {

            let dataObj = JSON.parse(data);

            dataObj.push(req.body);

            let dataJson = JSON.stringify(dataObj, null, 4);

            fs.writeFile(__dirname + "/data/student.json", dataJson, err => {
                if (err) {
                    console.log(err);
                } else {
                    res.status(200).send("ok");
                }
            });
        };
    });
});


//监听端口3000
app.listen(3000, () => {
    console.log("服务器 3000 端口 已经打开");
});