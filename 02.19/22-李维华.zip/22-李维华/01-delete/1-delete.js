// const fs = require('fs');

// 先判断是文件还是目录

// fs.stat('./files', (err, stats) => {
//     if (err) {
//         console.log(err);
//     } else {
//         if (stats.isDirectory()) {
//             console.log('是一个目录');
//         } else if (stats.isFile()) {
//             console.log('是一个文件');
//         }
//     };
// });

// fs.readdir('./files', (err, files) => {
//     if (err) {
//         console.log(err);
//     } else {
//         // files是一个数组---所有文件的文件名[ '1.txt', '2.txt', 'name.txt' ]
//         console.log(files);
//         // console.log(files[2]);
//     }
// });


//1. 封装函数
//2 判断所看文件夹是否有目录或文件
//3.遍历文件数组 判断是文件还是目录
//4. 判断是一个文件时  删除当前文件
//5.当不是一个文件   调用自己进行递归  进入当前文件夹  删除文件
//6.删除空目录


// 引入fs文件系统模块
const fs = require('fs');
// 封装函数
function delFiles(filesName) {
    // 返回一个包含“指定目录下所有文件名称”的数组对象
    var arrFiles = fs.readdirSync(filesName);
    console.log(arrFiles);
    // 通过for in 遍历文件中的文件或目录
    for (var index in arrFiles) {
        var stats = fs.statSync(filesName + '/' + arrFiles[index]);
        // 判断是否为一个文件  当是一个文件 
        if (stats.isFile()) {
            console.log('是一个文件');
            // 当是一个文件  删除当前文件
            fs.unlinkSync(filesName + '/' + arrFiles[index]);
            console.log("删除文件成功");
        } else {
            console.log('是一个目录');
            // 当不是一个文件   调用自己进行递归  进入当前文件夹  删除文件
            delFiles(filesName + '/' + arrFiles[index])
        }
    }
    // 遍历完一层  删除空的目录
    fs.rmdirSync(filesName);
    console.log("删除空目录成功");
}
// 调用函数
delFiles('./files');