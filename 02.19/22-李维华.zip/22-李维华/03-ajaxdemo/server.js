// 引入express模块
var express = require('express');
// post
var bodyParser = require('body-parser');
// 文件系统模块
var fs = require('fs');
// 初始化express
var app = express();

// 初始化静态资源
app.use(express.static('public'))
    // 设置读取格式
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.set('Content-Type', 'application/json');
    next();
});


app.get('/api/getstudents', (req, res) => {
    fs.readFile('data/student.json', 'utf-8', (err, data) => {
        if (err) {
            console.log('文件读取错误');
            console.log(err);
            res.status(500).end()
        } else {
            dataA = JSON.parse(data);
            // 结果
            let result = [];
            if (req.query.name) {
                dataA.forEach((value) => {
                    if (value.name == req.query.name) {
                        result.push(value)
                    }
                })
            } else {
                result = dataA;
            }
            console.log(dataA);
            res.status(200).send(result)

        }
    })
})


app.post("/api/addstudents", (req, res) => {
    fs.readFile('data/student.json', (err, data) => {
        if (err) {
            console.log('文件读取错误');
            console.log(err);
            res.status(500).end()
        } else {
            newData = JSON.parse(data);
            // 结果
            let result = req.body;
            // 添加id
            result.id = new Date().getTime();

            newData.push(result)

            // 写入文件  
            fs.writeFileSync('data/student.json', JSON.stringify(newData, null, 4))
            console.log(result);
            res.status(200).send(result)

        }
    })
})


app.listen(3000, function() {
    console.log('服务已经开启。后台接口地址： http://localhost:3000');
});