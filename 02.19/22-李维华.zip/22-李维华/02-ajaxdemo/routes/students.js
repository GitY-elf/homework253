var express = require('express');
var router = express.Router();
var fs = require('fs');


// 查询学生
router.get('/getStudent', (req, res) => {
    fs.readFile(__dirname + './../data/students.json', 'utf-8', (err, data) => {
        if (err) {
            res.status(500).end();
            return console.log(err);
        }
        try {
            data = JSON.parse(data)
        } catch (e) {
            res.status(500).end();
            return console.log(e);
        }

        // 将要返回的结果
        var results = [];
        // 指定id
        var myid = req.query.id;

        // 指定名字
        var myname = req.query.name;

        if (myid) {
            data.forEach(function(item, index) {
                if (item.id == myid) {
                    results.push(item);
                }
            });
        } else if (myname) {
            // 获取指定name的学生信息
            data.forEach(function(item, index) {
                if (item.name.includes(myname)) {
                    results.push(item);
                }
            });
        } else {
            results = data;
        }

        res.status(200).send(results);
    })
})



router.get('/jsonpdemo', function(req, res) {
    console.log("前台传递过来的方法名" + req.query.callback);
    var data = '[{"name": "张三"},{"name": "李四"},{"name": "王美丽"}]';
    console.log("接受请求");
    res.status(200).send(req.query.callback + +'(' + data + ')')
});

// 暴露接口

module.exports = router;