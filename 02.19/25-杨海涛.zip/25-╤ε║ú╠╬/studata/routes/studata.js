const express = require('express');
const app = express();
// let router = express.Router();
const fs = require('fs');
app.get('/getstudent',(req, res) => {
    fs.readFile(__dirname + './../data/datastu.json', 'utf-8', (err, data) => {
        if(err) {
            console.log('404 not found');
        }else {
            let dataArr = JSON.parse(data);
            // let arrData = [];
            // // 通过sId查找
            // let sId = req.query.sId;
            // if(sId) {
            //     dataArr.forEach(value => {
            //         if(value.sId == sId) {
            //             arrData.push(value)
            //         };
            //     });
            // }else {
                // arrData = dataArr;
            // };
            res.send(dataArr);
        };
        
    });
});
// module.exports = router;