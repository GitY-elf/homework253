const express = require('express');
const fs = require('fs')
const app = express();
const bodyParser = require('body-parser');
// 设置静态资源
console.log(__dirname);
app.use(express.static(__dirname));
// 配置POST请求的·参数
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// 跨域请求
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});
// app.use('/student', require('./routes/studata'));
app.get('/getstudent', (req, res) => {
    fs.readFile(__dirname + '/data/datastu.json', 'utf-8', (err, data) => {
        if (err) {
            console.log('404 not found');
        } else {
            let dataArr = JSON.parse(data);
            res.send(dataArr);
        };
    });
});
app.post('/addstudent', (req, res) => {
    console.log(req.body);
    fs.readFile(__dirname + '/data/datastu.json', 'utf-8', (err, data) => {
        // 转换为数组对象
        datas = JSON.parse(data);
        // 把新数据加入到数组中
        datas.push(req.body);
        // 重新写入数据
        fs.writeFile(__dirname + '/data/datastu.json', JSON.stringify(datas, null, 4), (err) => {
            if (err) {
                console.log('404 is found');
            } else {
                console.log('追加成功');
                res.send(datas);
            }
        });
    })
});
// 监听
app.listen(3000, () => {
    console.log('服务器正在运行');
})