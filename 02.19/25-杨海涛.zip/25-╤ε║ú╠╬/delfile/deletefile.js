const fs = require('fs');
// // 创建文件夹
// fs.mkdir('./aa/bb', {
//     recursive: true
// }, (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('文件夹创建成功');
//     }
// });
// // 写入
// fs.writeFile('./aa/bb/2.txt','Hello Nodejs', err => {
//     if(err) {
//         console.log(err);
//     } else {
//         console.log('写入成功');
//     }
// })

// // 删除非空文件夹
// fs.rmdir('./aa', {
//     recursive: true
// }, err => {
//     if(err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// })

function delfile(path) {
    const files = fs.readdirSync(path);
    // console.log(files);
    files.forEach(value => {
        let pathfile = `${path}/${value}`;
        // console.log(pathfile);
        // 同步有返回值，无回调
        let status = fs.statSync(pathfile);
        if (status.isDirectory()) {
            delfile(pathfile);
        } else if (status.isFile()) {
            fs.unlinkSync(pathfile);
        };
    });
    fs.rmdirSync(path);
};
delfile('./aa')