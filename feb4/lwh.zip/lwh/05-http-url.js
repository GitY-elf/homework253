let url = new URL("http://localhost:3000/login?uname=zhangmeil&password=666#8888");



console.log(url);

// 锚位置
console.log(url.hash);

// 主机名加端口号
console.log(url.host);

// 主机名
console.log(url.hostname);

// 完整的url
console.log(url.href);

// 域名
console.log(url.origin);

//  /login
console.log(url.pathname);

// 端口号
console.log(url.port);
// 协议
console.log(url.protocol);

// ?后面的
console.log(url.search);



console.log(url.searchParams);

console.log(url.toString());

console.log(url.toJSON());



let searchPar = url.searchParams;
console.log(searchPar);

for (let [key, value] of searchPar) {
    console.log(key);
    console.log(value);
}


searchPar.forEach((value, key) => {
    console.log(key);
    console.log(value);
});

// apppend
// delete

// entries

// get

// getAll   数组的形式


searchPar.append("gender", "男");
// searchPar.delete('password');/

console.log(searchPar);

// 键值对   数组的形式
console.log(searchPar.entries());
console.log(searchPar.has("uname"));

searchPar.append("key", "1");
searchPar.append("key", "2");
searchPar.append("key", "3");
console.log(searchPar.get('key'));
console.log(searchPar.getAll('key'));