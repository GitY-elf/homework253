// let http = require('http');
// // console.log(http);


// // creatServer()创建服务器

// // request请求

// // response:返回消息

// let server = http.createServer((req, res) => {
//     // 设置响应信息-相应类型以及编码格式

//     res.writeHead(200, {
//         "Content-Type": "text/html;charset=utf-8"
//     });
//     res.write('你好啊,欢迎访问');
//     res.end();
// });

// server.listen(3000, () => {
//     console.log("Server is running, press Ctrl + c  will stop ");
// })



let http = require('http');
// console.log(http);

let Server = http.createServer((req, res) => {
    // 设置响应头-相应类型及编码方式
    res.writeHead(200, {
        "Content-Type": "text/html;charset=utf-8"
    });
    res.write('你好啊,欢迎访问');
    res.write(`<div>你好啊,欢迎进入</div>`);
    res.end();
})

Server.listen(3000, () => {
    console.log("server is running ,Press ctrl + c will stop");
})