let http = require('http');
let fs = require("fs")

let server = http.createServer((req, res) => {
    console.log(req.url);
    res.writeHead(200, "success", {
        "Content-Type": "text/html;charset=utf-8"
    })
    if (req.url != '/favicon.ico') {
        let filepath = './files' + req.url;
        fs.readFile(filepath, (err, data) => {
            if (err) {
                console.log(err);
            } else {
                res.write(data)
            }
            // 读完响应结束
            res.end("end")
        })
    }

});

server.listen(3000, () => {
    console.log("server is running:3000");
})