let path = require('path');
// console.log(path);

//basename:path最后一部分文件名

// index.html
console.log(path.basename('http://www.hg-zn.com:3000/index.html'));

// index
console.log(path.basename('http://www.hg-zn.com:3000/index.html', ".html"));
//login?name=zhangmeili
console.log(path.basename('http://www.hg-zn.com:3000/login?name=zhangmeili', ".html"));


// 目录   path名
console.log(path.dirname('http://www.hg-zn.com:3000/public/index.html'));


// 文件的扩展名
console.log(path.extname('http://www.hg-zn.com:3000/public/index.html'));

// 转化为对象
console.log(path.parse('http://www.hg-zn.com:3000/public/index.html'));


// 拼接路径名
console.log(path.join("public", "index"));