let http = require('http');

let server = http.createServer((req, res) => {
    console.log(req.url);

    res.writeHead(200, "success", {
        "Content-Type": "text/html;charset=utf-8"
    })
    switch (req.url) {
        case `/`:
            res.write('home page');
            break;
        case `/index.html`:
            res.write('home page');
            break;
        case `/news.html`:
            res.write('news page');
            break;
        case `/about.html`:
            res.write('aboutus page');
            break;
        default:
            res.write('404 not find')
    }
    // 响应结束
    res.end('ok!!!')
});

server.listen(3000, () => {
    console.log("server is running:3000");
})