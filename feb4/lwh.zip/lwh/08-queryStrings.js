let http = require('http');
let queryStr = require('querystring')
let server = http.createServer((req, res) => {

    res.writeHead(200, "success", {
            "Content-Type": "text/html;charset=utf-8"
        })
        // 获取请求的url相关内容
        // http://localhost:3000/login?uname=zhangmeil&password=666
    console.log(req.url);
    // 转存对象

    let reqURL = req.url;
    if (reqURL != '/favicon.ico') {
        // 申明转存的对象
        let obj = {};
        if (reqURL.includes('?')) {
            let reqstr = reqURL.split("?")[1];
            console.log(reqstr);

            console.log(queryStr.parse(reqstr));
            res.end('结束')
        } else {
            res.end("无参数存储")
        }
    }

});

server.listen(3000, () => {
    console.log("server is running:3000");
})