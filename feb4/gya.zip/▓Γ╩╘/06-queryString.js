const queryStr = require('querystring');
let searchstr = 'uname=zhangmeili&password=666';

// 将字符串转换为对象
console.log(queryStr.parse(searchstr));
console.log(queryStr.stringify({
    uname: 'zhangmeili',
    password: '666'
}));
console.log(queryStr.stringify({
    uname: 'zhangmeili',
    password: '666'
}, '*', '-'));



// 编码和解码
console.log(queryStr.escape('node学习666'));
console.log(queryStr.unescape('node%E5%AD%A6%E4%B9%A0666'));
let codeStr = 'uname=%E5%BC%A0%E7%BE%8E%E4%B8%BD&pwd=666';
console.log(queryStr.parse(codeStr));
console.log(queryStr.unescape('%E5%BC%A0%E7%BE%8E%E4%B8%BD'));