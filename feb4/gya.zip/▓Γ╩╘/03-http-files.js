const http = require('http');
const fs = require('fs');
let server = http.createServer((req, res) => {
    console.log(req.url);
    res.writeHead(200, 'success', {
        'Content-Type': 'text/html;charset=utf-8'
    });
    if (req.url != '/favicon.ico') {
        let filePath = './files' + req.url;
        fs.readFile(filePath, (err, data) => {
            if (err) {
                console.log(err);
            } else {
                res.write(data);
            }
            res.end('结束');
        })
    }
});
server.listen(3000, () => {
    console.log('成功');
});