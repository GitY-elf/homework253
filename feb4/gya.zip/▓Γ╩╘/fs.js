// 引入模块
let fs = require('fs');
// console.log(fs);
// 读取文件
fs.readFile('./files/1.txt', 'utf-8', (err, data) => {
    if (err) {
        console.log(err);
    } else {
        console.log(data);
    }
});
// 写入
fs.writeFile('./files/2.txt', '你怕不是个憨憨吧', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('写入成功');
    }
});
// 追加
fs.appendFile('./files/2.txt', '曹雅萌', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('追加成功');
    }
});
// 删除
fs.unlink('./files/2.txt', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('已删除');
    }
});
// 重命名
fs.rename('./files/rename.txt', './files/cym.txt', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('重命名成功');
    }
});