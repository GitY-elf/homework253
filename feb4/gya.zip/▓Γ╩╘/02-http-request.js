const http = require('http');
let server = http.createServer((req, res) => {
    console.log(req.url);
    res.writeHead(200, 'success', {
        'Content-Type': 'text/html;charset=utf-8'
    });

    switch (req.url) {
        case '/':
            res.write('home page');
            break;
        case '/index.html':
            res.write('home page');
            break;
        case '/about.html':
            res.write('about page');
            break;
        case '/news.html':
            res.write('news page');
            break;
        default:
            res.write('404  NOT FOND');
    }
    res.end('ok呀!');
});
server.listen(3000, () => {
    console.log('成功');
});