const http = require('http');
const queryStr = require('querystring');
let server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-type': 'text/html;charset=utf-8'
    });
    console.log(req.url);
    let reqURL = req.url;
    if (req.url != '/favicon.ico') {
        let obj = {};
        if (req.url.includes('?')) {
            var reqstr = reqURL.split('?')[1];
            console.log(reqstr);
            // 转换为对象
            console.log(queryStr.parse(reqstr));
            res.end('提交成功');
        } else {
            res.end('失败');
        }
    }
});
server.listen(3000, () => {
    console.log('server is running:3000');
});