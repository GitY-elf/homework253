// 引入
let http = require('http');
// console.log(http);
// 创建服务器
let server = http.createServer((rep, res) => {
    // 设置响应信息和相应类型及编码格式
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
    });
    // 写入到前台
    res.write('你是个憨憨');
    res.write('<div>你好呀!</div>');

    // 结束
    res.end();
});
// 监听
server.listen(3000, () => {
    console.log('成功');
});