const http = require('http');
let server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-type': 'text/html;charset=utf-8'
    });
    console.log(req.url);
    let reqURL = req.url;
    if (reqURL != '/favicon.ico') {
        let obj = {};
        if (reqURL.includes('?')) {
            var arr = reqURL.split('?')[1].split('&');
            console.log(arr);
            arr.forEach((value) => {
                var temparr = value.split('=');
                obj[temparr[0]] = temparr[1];
            });
            console.log(obj);
            res.end('提交成功');
        } else {
            res.end('失败');
        }
    };
});
server.listen(3000, () => {
    console.log('server is running:3000');
});