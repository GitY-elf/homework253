// // 引用http
// let http = require('http');
// // 使用createServer创建服务器
// let Server = http.createServer((req, res) => {
//     console.log(req.url);
//     // 设置响应头
//     res.writeHead(200, {
//         'content-Type': 'text/html;charset=utf-8'
//     });
//     // /index.html
//     // /news.html
//     // /about.html
//     switch (req.url) {
//         case '/':
//             res.write('home page');
//             break;
//         case '/index.html':
//             res.write('index page');
//             break;
//         case '/news.html':
//             res.write('news page');
//             break;
//         case '/about':
//             res.write('about page');
//             break;
//         default:
//             res.write('404 Not found')
//     }
//     // 响应结束
//     // res.end('ok') 相当于res.write('ok');
//     // res.end();
//     res.end('ok');
// });
// // 监听响应
// Server.listen(3000, () => {
//     console.log('监听成功');
// });



// // 引用http
// let http = require('http');
// // 使用createServer创建服务器
// let Server = http.createServer((req, res) => {
//     console.log(req.url);
//     // 设置响应头
//     res.writeHead(200, {
//         'content-Type': 'text/html;charset=utf-8'
//     });
//     // /index.html
//     // /news.html
//     // /about.html
//     switch (req.url) {
//         case '/':
//             res.write('home page');
//             break;
//         case '/index.html':
//             res.write('index page');
//             break;
//         case '/news.html':
//             res.write('news page');
//             break;
//         case '/about':
//             res.write('about page');
//             break;
//         default:
//             res.write('404 Not found')
//     }
//     // 响应结束
//     // res.end('ok') 相当于res.write('ok');
//     // res.end();
//     res.end('ok');
// });
// // 监听响应
// Server.listen(3000, () => {
//     console.log('监听成功');
// });




// 引用http
let http = require('http');
// 使用createServer创建服务器
let Server = http.createServer((req, res) => {
    console.log(req.url);
    // 设置响应头
    res.writeHead(200, {
        'content-Type': 'text/html;charset=utf-8'
    });
    // /index.html
    // /news.html
    // /about.html
    switch (req.url) {
        case '/':
            res.write('home page');
            break;
        case '/index.html':
            res.write('index page');
            break;
        case '/news.html':
            res.write('news page');
            break;
        case '/about':
            res.write('about page');
            break;
        default:
            res.write('404 Not found')
    }
    // 响应结束
    // res.end('ok') 相当于res.write('ok');
    // res.end();
    res.end('ok');
});
// 监听响应
Server.listen(3000, () => {
    console.log('监听成功');
});