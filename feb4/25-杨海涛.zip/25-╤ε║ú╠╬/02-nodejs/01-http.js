let http = require('http');
let server = http.createServer((req,res) => {
    // 设置响应信息，相应类型及编码格式
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
    });
    res.write('Hello World!');
    res.end();
});
// 监听3000端口
server.listen(3000, ()=> {
    console.log('服务器正在运行');
})