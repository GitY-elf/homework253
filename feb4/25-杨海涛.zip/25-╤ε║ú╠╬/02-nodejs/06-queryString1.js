const http = require('http');
const qs = require('querystring');
let server = http.createServer((req, res) => {
    res.writeHead(200, 'OK', {
        'Content-type': 'text/html;charset=utf-8'
    });
    // 获取请求的url相关内容
    // http://localhost:3000/login?username=zhangmeili&password=123456
    console.log(req.url);
    let reqURL = req.url;
    if (reqURL != '/favicon.ico') {
        let obj = {};
        if (reqURL.includes('?')) {
            // username=zhangmeili&password=123456
            var reqstr = reqURL.split('?')[1];
            // 转换为对象
            // { uname: 'zhangmeili', password: '123456' }
            // 1. js原生
            arr.forEach((value) => {
                var tempArr = value.split('=');
                obj[tempArr[0]] = tempArr[1];
            });
            console.log(obj);
            // 2. nodejs
            console.log(qs.parse(reqstr));

            // 结束
            res.end('请求提交成功');
        } else {
            res.end();
        }
    };
});
// 开启端口的监听
server.listen(3000, () => {
    console.log('服务器正在运行');
});