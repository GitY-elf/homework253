const http = require('http');
const fs = require('fs');

let server = http.createServer((req,res) => {
    res.writeHead(200,{
        'Content-Type': 'text/html;charset=utf-8'
    });

    if(req.url != '/favicon.ico') {
        let filepath = './files' + req.url;
        fs.readFile(filepath,(err,data) => {
            if(err) {
                console.log(err);
            } else {
                res.write(data);
            }

            // ******结束必须写到读文件里面*******
            res.end('111');
        });  
    };
});
server.listen(3000, () => {
    console.log('服务器正在运行');
})