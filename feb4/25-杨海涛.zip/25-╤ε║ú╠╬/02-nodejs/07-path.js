const paths = require('path');

// path 最后一部分文件名   
// index.html
console.log(paths.basename('http://www.baidu.com:3000/index.html'));
// index.
console.log(paths.basename('http://www.baidu.com:3000/index.html','html'));
// login?uname=zhangmeili
// console.log(paths.basename('http://www.baidu.com:3000/login?uname=zhangmeili'));

// path 的目录名
// http://www.baidu.com:3000
console.log(paths.dirname('http://www.baidu.com:3000/index.html'));
// http://www.baidu.com:3000/files/page
console.log(paths.dirname('http://www.baidu.com:3000/files/page/index.html'));

// path 的url的扩展名
// .html
console.log(paths.extname('http://www.baidu.com:3000/index.html'));
// .md
console.log(paths.extname('http://www.baidu.com:3000/page.md'));

// path 的 parse
// {
//     root: '',
//     dir: 'http://www.baidu.com:3000/files/page',
//     base: 'index.html',
//     ext: '.html',
//     name: 'index'
// }
console.log(paths.parse('http://www.baidu.com:3000/files/page/index.html'));

// 路径的拼接
// E:\VScode\web25\files\page
console.log(paths.join('E:/\VScode/\web25','files','page'));