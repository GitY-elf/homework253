let qs = require('querystring');
let str = 'username=zhangmeili&password=123456';
// 将字符串转换为对象
// { username: 'zhangmeili', password: '123456' }
console.log(qs.parse(str));

// 将对象转换为字符串（窗体格式）
// username=zhangmeili&password=123456
console.log(qs.stringify({ username: 'zhangmeili', password: '123456' }));
// username-zhangmeili*password-123456
console.log(qs.stringify({ username: 'zhangmeili', password: '123456' },'*','-'));


// 编码与解码
// %E5%B0%8F%E5%B9%B4%E5%88%B0%E4%BA%86666
console.log(qs.escape('小年到了666'));
// 小年到了666
console.log(qs.unescape('%E5%B0%8F%E5%B9%B4%E5%88%B0%E4%BA%86666'));
// %E5%BC%A0%E7%BE%8E%E4%B8%BD 
// zhangmeili
let str1 = 'username=%E5%BC%A0%E7%BE%8E%E4%B8%BD&pwd=666';
console.log(qs.parse(str1));
console.log(qs.unescape('%E5%BC%A0%E7%BE%8E%E4%B8%BD'));