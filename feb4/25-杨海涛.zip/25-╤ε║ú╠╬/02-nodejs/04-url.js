let url = new URL('https://www.baidu.com:3000/?username=zhangmeili&password=123456');

let searchUrl = url.searchParams;
// URLSearchParams { 'username' => 'zhangmeili', 'password' => '123456' }
console.log(searchUrl);

// 协议  https:
console.log(url.protocol);
// ?及后面的部分
// ?username=zhangmeili&password=123456  
console.log(url.search);
// 端口号  3000
console.log(url.port);
// 对问号后的数据进行遍历
searchUrl.forEach((value,key) => {
    // zhangmeili  123456
    console.log(value); 
    // username  password
    console.log(key);
});

// 添加
searchUrl.append('gender',false);
searchUrl.append('sId','10010');
searchUrl.append('sId','10086');

// 删除
// searchUrl.delete('sId');

// 键
console.log(searchUrl.keys());
console.log(searchUrl.entries());
// 10010
console.log(searchUrl.get('sId'));
// [10010,10086]
console.log(searchUrl.getAll('sId'));
console.log(searchUrl.has('gender'));