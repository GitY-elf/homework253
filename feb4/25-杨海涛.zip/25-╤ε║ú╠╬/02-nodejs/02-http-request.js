const http = require('http');
let server = http.createServer((req,res) => {
    res.writeHead(200,'OK',{
        'Content-Type': 'text/html;charset=utf-8'
    });
    // 请求网址  req.url
    // 不同的网址返回不同的页面
    switch(req.url) {
        case '/':
            res.write('主页面');
            break;
        case '/index.html':
            res.write('首页');
            break;
        case '/other.html':
            res.write('其它页面');
            break;
        default:
            res.write('404 找不到页面');
    }
    // 结束
    res.end();
});
server.listen(3000, () => {
    console.log('服务器正在运行');
})