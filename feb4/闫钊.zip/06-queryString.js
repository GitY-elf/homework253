const queryString = require("querystring");
// querystring.decode()
// querystring.parse(str[, sep[, eq[, options]]])
// querystring.encode()
// querystring.stringify(obj[, sep[, eq[, options]]])
// querystring.escape(str)
// querystring.unescape(str)


let urlstr = "http://www.baidu.com:3000/page/index/css/index.html?name=sssd&pwd=12321#888";

console.log(queryString.parse(urlstr));
// [Object: null prototype] {
//     'http://www.baidu.com:3000/page/index/css/index.html?name': 'sssd',
//     pwd: '12321#888'
//   }
queryString.stringify();

queryString.escape(); //编码
queryString.unescape(); //解码