const http = require("http");
//
//request:请求
//response:响应
let server = http.createServer((req, res) => {
    res.writeHead(200, {
        "Content-Type": "text/html;charset=utf-8"
    });
    res.write("hello");
    res.write("你好啊");
    res.end();
});

server.listen(3030, () => {
    console.log('Server is running,Press Ctrl + C will stop');
});