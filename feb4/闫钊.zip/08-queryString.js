const http = require('http');
const queryStr = require("querystring");

//http://localhost:3003/page/index/css/index.html?name=sssd&pwd=12321#888
let server = http.createServer((req, res) => {
    //设置响应头
    res.writeHead(200, {
        "Content-Type": "text/html;charset=utf-8"
    });
    //得到请求的url
    let reqURL = req.url;
    if (reqURL != "/favicon.ico") {
        if (reqURL.includes("?")) {
            //保存url上的数据
            let serchStr = reqURL.split("?")[1];
            let obj = queryStr.parse(serchStr);
            console.log(obj);
            res.end();
        } else {
            console.log("没有参数传入");
            res.end();
        }
    }
});

server.listen(3003, () => {
    console.log("3003端口已打开");
});