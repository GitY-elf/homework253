const http = require("http");
const fs = require("fs");


let server = http.createServer((req, res) => {
    res.writeHead(200, {
        "Content-Type": "text/html;charset=utf-8"
    });
    let filesPath = "./files" + req.url;
    console.log(filesPath);
    fs.readFile(filesPath, "utf-8", (err, data) => {
        if (err) {
            console.log(err);
        } else {
            res.write(data);
        }
        res.end();
    })

});
server.listen(3000, () => {
    console.log("3000端口已打开");
});