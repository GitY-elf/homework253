const path = require("path");
const { stringify } = require("querystring");
let url = "http://localhost:3003/page/index/css/index.html?name=sssd&pwd=12321#888";
let base = path.basename(url, ".html");
//index.html?name=sssd&pwd=12321#888

let dir = path.dirname(url);
// http://localhost:3003/page/index/css

let ext = path.extname(url);
//.html?name=sssd&pwd=12321#888

let parse = path.parse(url);
/**
 * {
  root: '',
  dir: 'http://localhost:3003/page/index/css',
  base: 'index.html?name=sssd&pwd=12321#888',
  ext: '.html?name=sssd&pwd=12321#888',
  name: 'index'
}
 */
console.log(parse);
let join = path.join("111", "222");
// 111/222
console.log(join);