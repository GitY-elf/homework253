const http = require("http");
let server = http.createServer((request, response) => {
    response.writeHead(200, "success", {
        "Content-Type": "text/html;charset=utf-8"
    });
    switch (request.url) {
        case "/":
            response.write("/页面")
            break;
        case "/index.html":
            response.write("/index页面")
            break;
        case "/login.html":
            response.write("/login页面")
            break;
        default:
            response.write("404")
            break;
    }
    response.end();
});
server.listen(3000, () => {
    console.log("服务器已开启:3000");
})