const http = require("http");
let server = http.createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/html;charset=utf-8" });
    let reqURL = req.url;
    if (reqURL != "/favicon.icon") {
        let obj = {};
        let arr = reqURL.split("?")[1].split("&");
        console.log(arr);
        arr.forEach((value) => {
            let temp = value.split("=");
            obj[temp[0]] = temp[1];
        });
        // res.write(obj);
        res.end();
    }
});
server.listen(3000, () => {
    console.log("3000 ok");
})