let urlstr = "http://www.baidu.com:3000/page/index/css/index.html?name=sssd&pwd=12321#888";
let url = new URL(urlstr);
console.log(url);
// URL {
//     href: 'http://www.baidu.com:3000/page/index/css/index.html?name=sssd&pwd=12321#888',
//     origin: 'http://www.baidu.com:3000',
//     protocol: 'http:',
//     username: '',
//     password: '',
//     host: 'www.baidu.com:3000',
//     hostname: 'www.baidu.com',
//     port: '3000',
//     pathname: '/page/index/css/index.html',
//     search: '?name=sssd&pwd=12321',
//     searchParams: URLSearchParams { 'name' => 'sssd', 'pwd' => '12321' },
//     hash: '#888'
//   }

let searchParams = url.searchParams;
for (let [key, value] of searchParams) {
    console.log(key, value);
};
searchParams.append("gender", "女");
searchParams.delete("pwd");
searchParams.forEach((value, key) => {
    console.log(key, value);
});
searchParams.append("key", "111");
searchParams.append("key", "333");
searchParams.append("key", "222");
searchParams.get("name");
searchParams.getAll("key");