// 引入 mongoose模块

const mongoose = require('mongoose');

var express = require('express');

var app = express();

// 引入body-parser模块
const bodyParser = require('body-parser');

// 拦截请求
app.use(bodyParser.urlencoded({ extended: false }));

let DB = mongoose.connect('mongodb://localhost/getstudent', { useNewUrlParser: true, useUnifiedTopology: true });

DB.then(() => {
    console.log("数据库连接成功");
}, () => {
    console.log("数据库连接失败");
})

// 设置express设置模板引擎
app.set('view engine', 'ejs');

// 创建集合

const userSchema = new mongoose.Schema({
    className: String,
    name: String,
    gender: String,
    age: Number,
    address: String
});


// 利用Schema 创建集合mongoose.model
// model('user',userSchema):(表名,模板)
const User = mongoose.model('user', userSchema);

console.log(User);

//插入数据

// const user1 = new User({
//     className: "火花25",
//     name: "李华",
//     gender: "男",
//     age: "18",
//     address: "新乡"
// });
// user1.save();
// const user2 = new User({
//     className: "火花25",
//     name: "张美丽",
//     gender: "女",
//     age: "22",
//     address: "开封"
// });
// user2.save();

app.get('/', (req, res) => {
    // 查出数据
    User.find().then((result) => {
        console.log(result);
        res.render("getstudents", { studentsObj: result });
    });

});

// 查找单个
app.post('/api/getstudent', (req, res) => {
    console.log(req.body);

    if (req.body.name === "") {
        User.find().then((result) => {
            res.render("getstudents", { studentsObj: result });
        });
    } else {
        User.find(req.body).then((result) => {
            console.log(result);
            res.render("getstudents", { studentsObj: result });
        });
    }


});



// 跳转添加数据的页面
app.get('/add', (req, res) => {
    res.render("add");
});


// 添加数据信息
app.post('/api/getstudents', (req, res) => {
    console.log(req.body);

    User.find().then((result) => {
        console.log(result);
        User.create(req.body).then((rel) => {
            // console.log(rel);
            result.push(rel);
            res.render("getstudents", { studentsObj: result });
        });

    });
});



// 监听端口
app.listen(3000, () => {
    console.log('3000 is  running');
});