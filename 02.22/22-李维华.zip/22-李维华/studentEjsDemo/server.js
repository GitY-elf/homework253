// 1 安装  ejs express   引入fs
const fs = require('fs');
const express = require('express');
const app = express();

// 引入body-parser模块
const bodyParser = require('body-parser');

// 拦截请求
app.use(bodyParser.urlencoded({ extended: false }));

// 设置express设置模板引擎
app.set('view engine', "ejs");

// 获取所有学生的信息
app.get('/api/getstudents', (req, res) => {
    fs.readFile('./data/student.json', "utf-8", (err, data) => {
        if (err) {
            res.status(500).end()
            console.log(err);
        } else {
            studentsObj = JSON.parse(data);
            res.render("getstudents", studentsObj);
            // console.log(studentsObj);
        }
    })
})

// 获取单个学生的数据
app.post('/api/getstudent', (req, res) => {
    console.log(req.body.uname);
    fs.readFile('./data/student.json', "utf-8", (err, data) => {
        if (err) {
            console.log('文件读取错误');
            res.status(500).end()
        } else {
            data = JSON.parse(data);
            // 结果
            console.log(data);
            let newobj = [];
            if (req.body.uname) {
                data.forEach((value) => {
                    if (value.name == req.body.uname) {
                        newobj.push(value);
                        console.log(newobj);
                    }
                })
            } else {
                newobj = data;
            }
            res.render("getstudents", { studentsObj: newobj });
        }
    })

});


// 跳转添加数据的页面
app.get('/add', (req, res) => {
    res.render("add");
});


app.post('/api/getstudents', (req, res) => {
    console.log(req.body);
    fs.readFile('./data/student.json', "utf-8", (err, data) => {
        if (err) {
            console.log('文件读取错误');
            res.status(500).end()
        } else {
            newData = JSON.parse(data);
            newData.push(req.body);
            console.log(newData);
            fs.writeFileSync('data/student.json', JSON.stringify(newData, null, 4));
            res.render("getstudents", { studentsObj: newData });
        }
    })

});


app.listen(3000, () => {
    console.log("3000 is running");
});