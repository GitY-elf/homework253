const mongoose = require('mongoose');
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
let DB = mongoose.connect('mongodb://localhost/momokodb', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('连接成功');
}, () => {
    console.log('连接失败');
});

app.set('view engine', 'ejs');
// 创建集合
// 1.定义集合的规则(哪些字段,什么数据类型等)
// 2.根据规则创建集合创建集合
const userSchema = new mongoose.Schema({
    clazz: String,
    name: String,
    age: String,
    tel: String,
    address: String,
    remark: String,
    date: String,
    gender: String,
    hobby: String,
    id: String
});

const User = mongoose.model('user', userSchema);
console.log(User);

// 插入数据
// const user = new User({
//     clazz: "火花25",
//     name: "谢镇涛",
//     age: "18",
//     tel: "18739275589",
//     address: "漯河",
//     remark: "程序员",
//     date: "2020-12-08",
//     gender: "男",
//     hobby: "吃饭,睡觉",
//     id: "1607417640348"
// });
// // 将数据保存到集合中
// user.save();
// const user1 = new User({
//     clazz: "火花25",
//     name: "小北",
//     age: "20",
//     tel: "18567115268",
//     address: "郑州",
//     remark: "铁憨憨",
//     date: "2020-02-22",
//     gender: "男",
//     hobby: "敲代码",
//     id: "5152961654"
// });
// 将数据保存到集合中
// user1.save();

app.get('/', (req, res) => {
    User.find().then((result) => {
        res.render('index', { studentsObj: result });
    });
});
app.post('/getstudent', (req, res) => {
    User.find(req.body).then((result) => {
        res.render('index', { studentsObj: result });
    });
});
app.listen(3000, () => {
    console.log('成功');
});