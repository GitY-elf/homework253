const express = require('express');
// 不引入也可以
const ejs = require('ejs');
const fs = require('fs');
// 实例化
const app = express();

// 设置express设置模块引擎
app.set('view engine', 'ejs');
app.get('/', (req, res) => {
    fs.readFile('./data/student.json', 'utf-8', (err, data) => {
        // 判断如果读取发生错误
        if (err) {
            res.status(500).end();
            console.log(err);
        } else {
            studentsObj = JSON.parse(data);
            console.log(studentsObj);
            console.log(data);
            // 读取ejs文件然后传递studentsObj给ejs, 呈现html代码
            // ejs.renderFile('./views/index.ejs', studentsObj, (err, str) => {
            //     if (err) {
            //         res.writeHead(500, {
            //             'Content-type': 'text/plain;charset="utf-8'
            //         });
            //         res.end('500 - application ERROR')
            //     } else {
            //         res.writeHead(200, {
            //             'Content-type': 'text/html;charset="utf-8'
            //         });
            //         res.end(str);
            //     }
            // })
            res.render("index", studentsObj);
        }
    })
});
app.listen(3000, () => {
    console.log('监听开启');
})