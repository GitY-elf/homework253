const express = require('express');
const app = express();
const ejs = require('ejs');
// 设置express模板引擎
app.set('view engine','ejs');
// 引入mongoose
const mongoose = require('mongoose');
// 连接数据库
const DB = mongoose.connect('mongodb://localhost/studata', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('连接成功');
}, () => {
    console.log('连接失败');
});
// 定义集合规则
let userSchema = new mongoose.Schema({
    uname: String,
    age: Number,
    sId: Number,
    gender: Boolean
});
// 创建集合(表名，规则)
let User = mongoose.model('user', userSchema);
// 定义数据
// let user1 = new User({
//     uname: '世界',
//     age: 24,
//     sId: 123404,
//     gender: true
// });
// 保存数据
// user1.save();
app.get('/', (req, res) => {
    res.render('index');
});
app.get('/getstudent', (req, res) => {
    User.find().then(data => {
        // console.log(data);
        // data = JSON.parse(data);
        res.render('getdata', { 
            data: data,
            header: '学生详细信息'
        });
    });
});
app.listen(3000, () => {
    console.log('服务器正在运行');
});