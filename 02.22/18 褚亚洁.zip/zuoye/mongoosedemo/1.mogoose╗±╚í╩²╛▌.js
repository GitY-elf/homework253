// 引入mongoose模板
const mongoose = require('mongoose');
// 引入express模板
const express = require('express');
// 引入ejs模板
const ejs = require('ejs');
// 引入fs模板
const fs = require('fs');
const app = express();
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.set('view engine', 'ejs');
// 连接数据裤并返回连接对象
let DB = mongoose.connect('mongodb://localhost/momodb', { useNewUrlParser: true, useUnifiedTopology: true });
// 连接数据裤是否成功
DB.then(() => {
    console.log('连接成功');
}, () => {
    console.log('连接失败');
});
// 创建集合
const userSchema = new mongoose.Schema({
    uname: String,
    age: Number,
    gender: String
});
const User = mongoose.model('user', userSchema);
User.create({
    uname: "lihua",
    age: 18,
    gender: "男"
});
app.get('/', (req, res) => {
    User.find().then((result) => {
        console.log(result);
        res.render("index", { students: result })
    });
});
app.listen(3000, () => {
    console.log('3000 数据成功');
})