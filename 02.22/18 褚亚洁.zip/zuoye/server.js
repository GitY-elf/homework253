// 引入express模板
const express = require('express');
// 引入ejs模板
const ejs = require('ejs');
// 引入fs模板
const fs = require('fs');
const { LOADIPHLPAPI } = require('dns');

// 实例化express
const app = express();
// 设置express模板引擎
app.set('view engine', 'ejs');
// 请求数据
app.get('/', (req, res) => {
    fs.readFile('./data/students.json', 'utf-8', (err, data) => {
        if (err) {
            res.status(500).end();
            console.log(err);
        } else {
            data = JSON.parse(data);
            res.render("index", { students: data })
        }
    });
});
app.listen(3000, () => {
    console.log('3000 成功');
})