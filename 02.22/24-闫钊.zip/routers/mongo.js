//引入mongoose模块
const mongooes = require("mongoose");
//链接mongo数据库
const db = mongooes.connect("mongodb://localhost/studentdb", { useNewUrlParser: true, useUnifiedTopology: true });
db.then(() => console.log("数据库连接成功"), () => console.log("数据库链接失败"));

//创建规则
const studentSchema = new mongooes.Schema({
    uname: String,
    age: Number,
    hobby: String
});

var User = mongooes.model('studentinfo', studentSchema)

//查询所有的数据
function getstudent(callback) {
    User.find().then((data) => {
        callback(data);
    });
};

//给数据库添加数据
function addstudent(obj, callback) {
    let add = new User(obj);
    add.save();
    callback();
};

module.exports.getstudent = getstudent;
module.exports.addstudent = addstudent;