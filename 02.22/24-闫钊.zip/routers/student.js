const express = require("express");
const ejs = require("ejs");
const bodyParser = require("body-parser");

const mongo = require("./mongo");

const app = express();
var router = express.Router();


router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());


app.set("view engine", "ejs");
// app.set("views", __dirmae + "/views");

// router.get("/getstudent", (req, res) => {
//     let students = mongo.getstudent();
//     res.render("/index", { header: "全部信息", students: students })
// });


router.get("/getstudent", (req, res) => {
    mongo.getstudent((students) => {
        res.render("index", { title: "全部信息", students: students })
    });
});

module.exports = router;