//引入mongoose模块
const mongooes = require("mongoose");
//链接mongo数据库
const db = mongooes.connect("mongodb://localhost/studentdb", { useNewUrlParser: true, useUnifiedTopology: true });
db.then(() => console.log("数据库连接成功"), () => console.log("数据库链接失败"));

//创建规则
const studentSchema = mongooes.Schema({
    uname: String,
    age: Number,
    hobby: String
});

var User = mongooes.model('studentinfo', studentSchema);
let dataobj = {
    uname: "钱六",
    age: 30,
    hobby: "睡觉,学习"
}

const use = new User(dataobj);
use.save();