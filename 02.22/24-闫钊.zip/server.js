//引入express框架
const express = require("express");

//引入ejs模块
const ejs = require("ejs");

//
const bodyParser = require("body-parser");

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//设置静态资源
app.use(express.static(__dirname));

app.set("view engine", "ejs");
app.set("views", __dirname + "/views");

const mongo = require("./routers/mongo");

//设置跨域
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.set('Content-Type', 'application/json');
    next();
});


//查询所有的数据
app.get("/getstudent", (req, res) => {
    mongo.getstudent((students) => {
        res.render("index", { title: "全部信息", students: students })
    });
});

//添加数据
app.post("/addstudent", (req, res) => {
    console.log(req.body);
    mongo.addstudent(req.body, () => {
        res.status(200).send("数据添加成功");
    });
});


// http://localhost:3000/api/student/getstudent

// app.use("/api/student", require("./routers/student.js"))


app.listen(3000, () => console.log("3000 OK!"));