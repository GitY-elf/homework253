const express = require("express");
const router = express.Router();

// 进入登陆页面
router.get("/login", require("./user-routes/login.js"));
//验证用户账户密码*
router.post("/verifyUser", require("./user-routes/verifyUser.js"));
//进入用户列表页面
router.get("/userlist", require("./user-routes/userlist.js"));

//添加用户信息页面
router.get("/adduser", require("./user-routes/adduser.js"));
//添加用户信息*
router.post("/doadduser", require("./user-routes/doadduser.js"))

//edituser  修改用户信息页面
router.get("/edituser/:id", require("./user-routes/edituser.js"));
//updateuser 修改用户信息*
router.post("/updateuser/:id", require("./user-routes/updateuser.js"));

//删除用户信息
router.get("/removeuser/:id", require("./user-routes/removeuser.js"));







module.exports = router;