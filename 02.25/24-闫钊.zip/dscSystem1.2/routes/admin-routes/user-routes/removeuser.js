const User = require("../../../db/userschma");
module.exports = async(req, res) => {
    await User.deleteOne({ _id: req.params.id });
    res.redirect("/admin/userlist");
};