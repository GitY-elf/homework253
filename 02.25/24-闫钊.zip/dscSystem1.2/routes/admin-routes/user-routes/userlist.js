/* 用户列表页面 */
const User = require("../../../db/userschma");

module.exports = async(req, res) => {
    let userlist;
    let username = req.query.username;

    if (username) {
        userlist = await User.find({ username: RegExp(req.query.username) });
    } else {
        username = "";
        userlist = await User.find();
    };

    // 当前第几页
    let page = Number(req.query.page) || 1;
    //总条数
    let userNum = userlist.length;
    //一页多少条数据
    let pageNum = req.query.pageNum || 5;
    //总页数
    let pageCon = Math.ceil(userNum / pageNum);

    //当前页面要显示的数据
    let pageUserMass;
    if (req.query.username) {
        pageUserMass = await User.find({ username: RegExp(req.query.username) }).limit(pageNum).skip((page - 1) * pageNum);
    } else {
        pageUserMass = await User.find().limit(pageNum).skip((page - 1) * pageNum);
    };

    res.render("./admin/userlist", {
        //查询对象的用户名
        username: username,
        //显示一页的数据
        pageUserMass: pageUserMass,
        //总页数
        pageCon: pageCon,
        // 当前第几页
        page: page,
        //一页多少条数据
        pageNum: pageNum,
        //总条数
        userNum: userNum
    })
};