/* 修改用户信息 */
const User = require("../../../db/userschma");
module.exports = async(req, res) => {
    let userid = req.params.id;
    let userMessage = await User.findOne({ _id: userid });
    res.render("./admin/edituser", { userMessage: userMessage });
};