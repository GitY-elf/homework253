/* 数据库 添加用户信息 */
const User = require("../../../db/userschma");
const md5 = require("md5");
module.exports = async(req, res) => {
    req.body.password = md5(req.body.password)
    let addMessage = await User.create(req.body);
    console.log(addMessage);
    res.redirect("/admin/userlist");
};