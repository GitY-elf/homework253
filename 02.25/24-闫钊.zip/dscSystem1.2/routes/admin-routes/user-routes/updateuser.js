/* 修改用户信息 */
const User = require("../../../db/userschma");
const md5 = require("md5");
module.exports = async(req, res) => {

    let userid = req.params.id;
    let userinfo = await User.findById(userid);
    console.log(userinfo);
    req.body.password = md5(req.body.password);

    await User.updateOne({ _id: userid }, req.body);
    res.redirect("/admin/userlist");
};