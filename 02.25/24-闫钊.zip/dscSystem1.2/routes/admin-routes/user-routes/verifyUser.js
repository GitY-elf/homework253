/*验证用户登陆信息 */
const User = require("../../../db/userschma");
const md5 = require("md5");

module.exports = async(req, res) => {
    let username = req.body.username;
    let findUser = {
        username: username,
        password: md5(req.body.password)
    };
    let findUserName = await User.findOne({ username: username });
    let findUserMessage = await User.findOne(findUser);

    if (!findUserName) {
        res.type("html");
        res.send("<script>location.href='/admin/login';alert('账户名错误');</script>");
    } else {
        if (findUserMessage) {
            //将登陆的用户名保存在session中
            req.session.username = username;
            res.redirect("/admin/userlist");
        } else {
            res.type("html");
            res.send("<script>location.href='/admin/login';alert('密码错误');</script>");
        };
    };
};