const express = require("express");
const app = express();
app.use(express.static("public"));

require("./db/db");

const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

require("ejs");
app.set("view engine", "ejs");

const session = require("express-session");
app.use(session({
    secret: "dscABC",
    resave: false,
    saveUninitialized: true,
    cookie: {
        maxAge: 24 * 60 * 60 * 1000
    },
    //强制重置cookie过期时间
    rolling: true
}));


app.use((req, res, next) => {
    let reqUrl = req.url;
    if (reqUrl != "/admin/login" && reqUrl != "/admin/verifyUser" && !req.session.username) {
        res.redirect("/admin/login");
    } else {
        next();
    };

});


app.use("/admin", require("./routes/admin-routes/admin.js"));



app.listen(3000, () => {
    console.log("3000端口已经开启");
})