const express = require('express');
const router = express.Router();

// 登录
router.get('/login', require('./main-router/login.js'));
// 商品列表
router.get('/goodslist', require('./main-router/goodslist.js'));
// 商品添加
router.get('/goodsadd', require('./main-router/goodsadd.js'));
// 商品删除
router.get('/goodsedit', require('./main-router/goodsedit.js'))

// 暴露
module.exports = router;