module.exports = (req, res) => {
    res.render('./login.ejs')
}