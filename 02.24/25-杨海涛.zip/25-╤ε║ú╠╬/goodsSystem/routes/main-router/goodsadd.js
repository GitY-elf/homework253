module.exports = (req, res) => {
    res.render('./goodsadd.ejs')
}