module.exports = (req, res) => {
    res.render('./goodslist.ejs')
}