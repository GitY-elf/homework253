const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');

// 设置静态资源
app.use(express.static('public'));
// 跨域解决
app.use(cors());
// 设置模板引擎
app.set('view engine','ejs');
// post请求
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

app.use('/', require('./routes/main.js'))


app.listen(3000, () => {
    console.log('服务器正在运行');
})
