const express = require('express');
const app = express();
const session = require('express-session');

app.use(session({
    secret: 'abc',
    name: 'aaa',
    resave: false,
    saveUninitialized: true,
    cookie: {
        // https协议
        // secure: true,
        maxAge: 20 * 1000
    },
    rolling: true
}));

app.get('/login', (req, res) => {
    req.session.uname = '安庆';
    res.status(200).send('登录成功');
});
app.get('/user', (req, res) => {
    res.status(200).send('欢迎'+ req.session.uname +'登录');
});

app.listen(3000, () => {
    console.log('服务器正在运行');
})