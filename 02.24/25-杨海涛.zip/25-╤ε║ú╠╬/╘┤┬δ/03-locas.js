const express = require('express');
const app = express();
const ejs = require('ejs');

app.set('view engine','ejs');
// app.set('views', __dirname);

//设置一个ejs中使用的公共数据
app.locals.title = '元宵节快乐';

app.get('/login', (req, res) => {
    res.render('./login.ejs')
});
app.get('/index', (req, res) => {
    res.render('./index.ejs')
});

app.listen(3000, () => {
    console.log('服务器正在运行');
})