// 引入模块
const express = require('express');
const app = express();
const cookieParser = require('cookie-parser');

// 拦截cookie操作
// app.use(cookieParser());
// cookie签名加密
app.use(cookieParser('abcd'));

app.get('/setCookie', (req, res) => {
    res.cookie('sId', 12358, {
        maxAge: 7 * 24 * 60 * 60 * 1000,
        // cookie签名加密
        signed: true
    });
    res.send('设置成功');
});

app.get('/getCookie', (req, res) => {
    console.log(req.cookies);
    console.log(req.signedCookies);
    res.send(req.signedCookies)
});

app.listen(3000, () => {
    console.log('服务器正在运行');
})