// 引入mongoose模块
const mongoose = require('mongoose');

// 连接数据库

let DB = mongoose.connect("mongodb://localhost/goodsdb", { useNewUrlParser: true, useUnifiedTopology: true });

// 监听数据库连接

DB.then(() => {
    console.log("数据库连接成功");
}, () => {
    console.log("数据库连接失败");
})


// 创建规则
const userSchema = new mongoose.Schema({
    title: String,
    pic: String,
    price: Number,
    fee: String,
    description: String

});

// 利用规则创建集合
const User = mongoose.model('User', userSchema);

// 插入数据
// User.create({
//     name: '王百川',
//     age: 20,
//     gender: '男'
// }).then((rel) => {
//     console.log(rel)
// });

// User.create([{
//         "clazz": "火花25",
//         "name": "谢镇涛",
//         "age": "18",
//         "tel": "18739275589",
//         "address": "漯河",
//         "remark": "程序员",
//         "date": "2020-12-08",
//         "gender": "男",
//         "hobby": "吃饭,睡觉",
//         "id": "1607417640348"
//     },
//     {
//         "gender": "女",
//         "hobby": "睡觉",
//         "address": "焦作",
//         "clazz": "火花25",
//         "name": " 张美丽",
//         "age": "12",
//         "tel": "18537289333",
//         "remark": "小公主",
//         "date": "2020-12-8",
//         "id": "1607417840533"
//     },
//     {
//         "clazz": "火花25",
//         "name": "王峰阳",
//         "age": "18",
//         "tel": "18739275589",
//         "address": "郑州",
//         "remark": "教授",
//         "date": "2020-12-08",
//         "gender": "男",
//         "hobby": "吃饭,睡觉",
//         "id": "1607417916504"
//     }
// ]).then((rel) => {
//     console.log(rel)
// });