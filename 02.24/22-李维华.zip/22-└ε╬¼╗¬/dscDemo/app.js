const express = require("express");
const app = express();
const ejs = require('ejs');
const bodyParser = require("body-parser");
const cors = require("cors");


// 设置模板引擎 
app.set("view engine", "ejs");

// 跨域
app.use(cors());

// post请求信息

app.use(bodyParser.urlencoded({
    extended: false
}));

app.use(bodyParser.json());
// 静态托管
app.use(express.static('public'));

// 配置路由信息
const admin = require("./routes/admin.js");

app.use("/admin", admin);

app.listen(3000, () => {
    console.log("3000 is running");
})