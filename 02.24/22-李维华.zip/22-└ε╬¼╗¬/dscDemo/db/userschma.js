const mongoose = require('mongoose');


// 创建规则
const userSchema = new mongoose.Schema({
    title: String,
    pic: String,
    price: Number,
    fee: String,
    description: String

});


// 利用规则创建集合
const User = mongoose.model('User', userSchema);
// 暴露出去.使用User
module.exports = User