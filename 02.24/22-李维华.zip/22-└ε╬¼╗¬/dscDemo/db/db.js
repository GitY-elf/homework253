// 引入mongoose模块
const mongoose = require('mongoose');

// 连接数据库

let DB = mongoose.connect("mongodb://localhost/goodsdb", { useNewUrlParser: true, useUnifiedTopology: true });

// 监听数据库连接

DB.then(() => {
    console.log("数据库连接成功");
}, () => {
    console.log("数据库连接失败");
})