const express = require("express");
const router = express.Router();

// 页面登录操作
router.get("/login", require("./admin-router/login.js"));

// 页面列表
router.get("/productlist", require("./admin-router/productlist.js"));

// 页面添加
router.get("/productadd", require("./admin-router/productadd.js"));

// 页面修改
router.get("/productedit", require("./admin-router/productedit.js"));

module.exports = router;