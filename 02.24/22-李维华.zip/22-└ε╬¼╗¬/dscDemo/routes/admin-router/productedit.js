// 引入修改商品的页面
module.exports = (req, res) => {
    res.render("./admin/productedit")
}