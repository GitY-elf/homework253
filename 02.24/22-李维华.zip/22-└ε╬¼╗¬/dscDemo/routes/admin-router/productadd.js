// 引入添加商品的页面
module.exports = (req, res) => {
    res.render("./admin/productadd")
}