const express = require("express");
const app = express();

app.set("view engine", "ejs");

app.locals.title = "张美丽";

app.get("/login", (req, res) => {
    res.render("login")
});

app.get("/index", (req, res) => {
    res.render("index")
});

app.listen(3000, () => {
    console.log("3000 ok!");
})