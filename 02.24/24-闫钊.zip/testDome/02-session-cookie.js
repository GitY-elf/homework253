const express = require("express");
const app = express();

const session = require("express-session");
//session简介
//session是一种记录客户端状态的应用,session运行在服务端,当客户端第一次访问时,可以记录客户的登录信息等
//当客户再次访问时,可以判定登录状态,作出提示,进行拦截工作

app.use(session({
    //签名加密
    secret: "aaabbb",
    name: "seccapp",
    //强制保存session:默认true不保存,false保存
    resave: false,
    //强制保存未初始化session
    saveUninitialized: true,
    cookie: {
        //https协议
        // secure:true,
        //存活时间
        maxAge: 24 * 3600 * 1000
    },
    //强制重置cookie过期时间
    rolling: true
}));

app.get("/login", (req, res) => {
    req.session.name = "zhangmeili";
    res.status(200).send("登陆成功")
});

app.get("/index", (req, res) => {
    if (req.session.name) {
        res.send(200, "欢迎" + req.session.name);

    } else {
        res.send(404, "请重新登陆");
    }
});

app.listen(3000, () => {
    console.log("3000.......");
})