const express = require("express");
const app = express();

const cookieParser = require("cookie-parser");
//use设置cookie拦截
app.use(cookieParser("aaabbb"));

app.get("/login", (req, res) => {
    // res.cookie(key,value,Option)
    res.cookie("uname", "zml", {
        //开启签名加密
        signed: true,
        //设置过期的时间
        maxAge: 24 * 3600 * 1000
    });
    res.status(200).send("登陆成功");
});

app.get("/index", (req, res) => {
    //得到cookie的值
    // req.cookie;
    console.log(req.cookies);
    //得到签名加密的cookie
    console.log(req.signedCookies)
    res.status(200).send(req.signedCookies);
});

app.listen(3000, () => {
    console.log("3000........");
})