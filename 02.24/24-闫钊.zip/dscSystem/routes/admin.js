const express = require("express");
const router = express.Router();


router.get("/login", require("./admin-routes/login.js"));

router.get("/productlist", require("./admin-routes/productlist.js"));

router.get("/productadd", require("./admin-routes/productadd.js"));

router.get("/productedit", require("./admin-routes/productedit.js"));

module.exports = router;