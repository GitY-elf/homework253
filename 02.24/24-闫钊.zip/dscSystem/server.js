const express = require("express");
const app = express();

app.use(express.static("public"));

const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const cors = require("cors");
app.use(cors());

const ejs = require("ejs");
app.set("view engine", "ejs");

app.locals = {

}

app.use("/admin", require("./routes/admin.js"))


app.listen(3000, () => {
    console.log("3000端口已经开启");
});